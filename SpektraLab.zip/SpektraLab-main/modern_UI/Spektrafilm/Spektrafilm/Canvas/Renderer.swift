//  Renderer.swift — owns the Metal state for the canvas and the offscreen
//  Layer 2 pass used by export.
//
//  Draw-on-demand: the MTKView is paused and `needsDisplay` is set on state
//  change (UI-GUIDELINE §4). Each draw: (1) if Layer 2 or its input changed,
//  run the `layer2` kernel into `adjusted` and the `histogram` kernel over it;
//  (2) blit `adjusted` (or the original, while Space is held) to the drawable
//  through the sampling transform. The histogram buffer is read back on the
//  command buffer's completion and published on the main actor.
//
//  **The canvas draws the working space and does not convert it.** Every
//  texture here is the session's resolved `io.output_color_space` — ProPhoto
//  RGB — and the `CAMetalLayer` is *tagged* with it, so ColorSync converts for
//  the display. `original` is in the working space too, at the decode
//  (`ImageDecoder.makePreviewTexture`), so the before/after split compares two
//  renderings and not two colour spaces.
//
//  That is a reversal, and the file is the wrong place for the argument: RFC-018
//  §2.4 built the output transform for the canvas as well, on the grounds that
//  a matrix profile has no perceptual table and so ColorSync clips where CAM16
//  rolled off. The user took the decision back on 2026-09-13 — "all displayed
//  image in the main app page would be in ProPhoto RGB and macOS should be
//  handling the color space management" — having heard the objection. D2 in
//  that RFC records both sides, and §7.2's numbers say what it costs.
//
//  The transform itself is not gone: export and the soft proof still run it,
//  once, per destination, into the recipe's space. It is below, under "the
//  output transform — export and the proof only".

import Foundation
import Metal
import MetalKit
import QuartzCore

/// The ground behind the picture — the letterbox around a frame that does not
/// fill the canvas — **in the working space's encoding**.
///
/// The drawing's value is `0x5F/255`, and it is an *sRGB-encoded* grey: that is
/// what `Theme.ground` names and what every capture since the drawing has
/// shown. The canvas carries it in ProPhoto now, and the same number means a
/// different colour there — γ1.8 is the flatter curve, so ROMM-encoded 0x5F
/// decodes to **1.478× the light**. Left alone, the whole interface would have
/// shifted lighter around the picture.
///
/// Derived rather than written down: sRGB 0x5F decodes to linear 0.11444 and
/// ROMM γ1.8 encodes that to 0.29990. Both steps are here, so a change to
/// either moves the ground with it. `Theme.ground` stays the sRGB literal it
/// is, because AppKit draws that one and colour-manages it itself.
///
/// Three things paint this ground and all three take the value from here: the
/// shader's letterbox (`CanvasUniforms.surroundGray`), the clear colour, and
/// the layer's background behind the drawable.
///
/// The mask overlay's red is the same problem and is handled in the shader
/// (`layer2`), where it is mixed into the picture: `0.85, 0.15, 0.15` read as
/// sRGB is the red the interface was drawn with, and γ1.8 re-encodes it to
/// `0.81507, 0.11255, 0.11255`. It is not here because it is not a uniform —
/// it never changes, and a uniform that cannot change is a uniform that can
/// disagree with the one place it is used.
enum CanvasGround {
    static let value: Float = {
        let encoded = 0x5F / 255.0
        let linear = encoded <= 0.040449936 ? encoded / 12.92
                                            : pow((encoded + 0.055) / 1.055, 2.4)
        return Float(linear < 1.0 / 512.0 ? linear * 16 : pow(linear, 1.0 / 1.8))
    }()
}

struct CanvasUniforms {
    var viewportSize = SIMD2<Float>(1, 1)
    /// The **output** size in logical pixels — the crop's size, not the
    /// texture's. Everything the viewport measures is in these units.
    var imageSize = SIMD2<Float>(1, 1)
    var offset = SIMD2<Float>(0, 0)
    /// Device pixels per output logical pixel.
    var scale: Float = 1
    var surroundGray: Float = CanvasGround.value

    /// Device pixels per *source texture* pixel. With a crop applied this is
    /// no longer `scale`, and it is the one the sampler choice is made on.
    var magnification: Float = 1
    var geometry = Geometry.Uniform()
    var editingCrop: UInt32 = 0
    var checker: UInt32 = 0
    /// 0 off · 1 split · 2 before-only. See `CompareMode`.
    var compare: UInt32 = 0
    /// Where the split sits, 0…1 across the output.
    var compareSplit: Float = 0.5
    /// The crop tool's pivot, normalised to the source. Edit space rotates
    /// about it — `Geometry.sourcePoint(forEdit:pivot:imageSize:)` — and it
    /// is what keeps the frame still: while it is the crop's centre the
    /// photo turns under a level frame. Only read while `editingCrop != 0`.
    var pivot = SIMD2<Float>(0.5, 0.5)
}

/// The before/after comparison, as the canvas understands it.
///
/// `split` is the one the toolbar button turns on and the one the reference
/// shows: a vertical line with the decoded frame on its left and the print on
/// its right, dragged by a handle. `before` is the whole-canvas version, which
/// is what Space has always done and what the toggle button in the print panel
/// does — it is here so that both go through one code path in the shader
/// rather than two that can disagree about sampling.
enum CompareMode: UInt32, Sendable { case off = 0, split = 1, before = 2 }

@MainActor
final class Renderer: NSObject {
    let device: MTLDevice
    let queue: MTLCommandQueue
    let store: TextureStore
    let arena: MemoryArena
    let scratchPool: Bool
    private let layer2Pipeline: MTLComputePipelineState
    private let transformPipeline: MTLComputePipelineState
    private let histogramPipeline: MTLComputePipelineState
    private let geometryPipeline: MTLComputePipelineState
    private let pairPipeline: MTLComputePipelineState
    private let quadPipelineDrawable: MTLRenderPipelineState
    private let quadPipelineOffscreen: MTLRenderPipelineState
    private let curveTable: MTLTexture
    private let histogramBuffer: MTLBuffer
    /// `[moved, clipped, outside]`, the output transform's counters (RFC-018
    /// §5.3, and see `cam16ucsInto` for why there are three). Shared storage,
    /// so the export's synchronous path reads them straight off the CPU after
    /// `waitUntilCompleted` with no blit.
    private let transformStats: MTLBuffer
    private var histogramInFlight = false

    /// The interactive, live-tier image: the print if there is one, else the
    /// decode preview. This is what the canvas shows at fit and while zoomed
    /// out, and it is the texture the service's ~0.4 s reprints replace.
    private(set) var live: MTLTexture?
    /// The frame at its **own** resolution: a print rendered from the current
    /// parameters, one per settled edit, and what the canvas settles on.
    ///
    /// Kept separate from `live` (the preview resolution) so the fast render
    /// can go up while this one is still being made, and so the swap costs
    /// nothing when it lands. **Not** `original`, which is the untouched
    /// *decode* — this is a render, and the canvas shows it as the picture.
    private(set) var fullRender: MTLTexture?
    /// Whether `fullRender` is the image on screen. False while the canvas is
    /// showing the preview resolution — at fit, and for the second or so
    /// after an edit while the native render is on its way.
    private(set) var showsFullRender = false
    /// The image the viewport is expressed against: the **frame's** own pixel
    /// size — the crop's, when one is applied — not the pixel size of whatever
    /// tier is on screen (D4). A resolution swap must not move the view, and a
    /// zoom must mean one frame pixel per device pixel, so `scale` stays
    /// points-per-frame-pixel and the draw takes the texture's own ratio into
    /// account in `canvasUniforms`.
    var logicalImageSize: CGSize? {
        viewport.image == CGSize(width: 1, height: 1) ? nil : viewport.image
    }
    /// What the canvas draws: the detail print when one is shown, else the
    /// live print or decode preview.
    var base: MTLTexture? { showsFullRender ? (fullRender ?? live) : live }
    /// The display decode at the frame's **own** resolution — Apple's
    /// rendering of the RAW, never the engine's input. Shown instead of the
    /// adjusted image while Space is held, and left of the split.
    ///
    /// Native, not the live tier (D3). It used to be a 1600 px preview with a
    /// second, lazily-rendered copy at whatever resolution was on screen, so
    /// that a before/after at 200 % did not compare a stretched decode against
    /// a sharp print. One native texture makes that ladder unnecessary: it is
    /// a picture of the frame at every zoom, and it is one texture per
    /// selected frame rather than one per tier visited.
    private var originalHandle: MemoryArena.Handle?
    var original: MTLTexture? { didSet { if let h = originalHandle { arena.release(h) }; originalHandle = original.flatMap { arena.registerPinned(bytes: $0.width * $0.height * 8, kind: "original") } } }
    private var adjustedHandle: MemoryArena.Handle?
    private var adjusted: MTLTexture? { didSet { if let h = adjustedHandle { arena.release(h) }; adjustedHandle = adjusted.flatMap { arena.registerPinned(bytes: $0.width * $0.height * 8, kind: "adjusted") } } }
    /// Rasterised coverage for the mask kinds that cannot be closed-form.
    /// Nothing writes it yet — brush and the Vision sources are the next
    /// component kinds and this is the seam they land on
    /// (`MaskComponentKind.isRaster`, `MaskUniform.rasterSlice`).
    private var maskHandle: MemoryArena.Handle?
    var maskRasters: MTLTexture? {
        didSet {
            if let h = maskHandle { arena.release(h) }
            maskHandle = maskRasters.flatMap {
                // The array slices and pixel format are part of this number.
                arena.registerPinned(bytes: $0.allocatedSize, kind: "maskRasters")
            }
        }
    }
    /// True when Layer 2's output is stale.
    ///
    /// There is no companion "the display is stale" any more, and its absence
    /// is the point: the canvas draws the working-space texture **as it is**,
    /// tagged with the working space, and ColorSync converts it for the
    /// display. Nothing between Layer 2 and the drawable has to be re-run when
    /// something upstream changes.
    private var layer2Dirty = true

    var viewport = ViewportState()
    var showOriginal = false { didSet { if oldValue != showOriginal { needsDraw?() } } }
    /// Split-view before/after. Independent of `showOriginal`: holding Space
    /// while a split is up shows the whole original, and releasing it returns
    /// to the split, which is what both gestures separately promise.
    var compareSplit = false { didSet { if oldValue != compareSplit { needsDraw?() } } }
    /// The split's position, 0…1 across the **output** (the cropped picture),
    /// so it stays on the same part of the frame under pan and zoom.
    var comparePosition: Float = 0.5 {
        didSet {
            comparePosition = comparePosition.clamped(to: 0...1)
            if oldValue != comparePosition { needsDraw?() }
        }
    }
    /// Whether a comparison can be shown at all: there has to be something to
    /// compare against. `original` is nil until the decode preview lands.
    var canCompare: Bool { original != nil }
    /// What the shader is told to do, from the three pieces of state above.
    ///
    /// Space wins over the split: it is a momentary gesture meaning "show me
    /// all of the original", and `draw` has already swapped the shown texture
    /// for the original to serve it — so the comparison is simply off, and the
    /// split comes back on release because nothing here writes `compareSplit`.
    var compareMode: CompareMode {
        (original == nil || showOriginal) ? .off : (compareSplit ? .split : .off)
    }
    /// Crop, straighten, quarter turns and flips. Applied to what the canvas
    /// draws, not only to what export writes — the two disagreeing is what
    /// made the old crop a lie past the canvas edge.
    var geometry = Geometry.default {
        didSet {
            guard oldValue != geometry else { return }
            // The re-pivot rule lives at this assignment because it is the
            // one write every angle change goes through: the panel's slider
            // and menu hand `session.geometry` a new value, the canvas
            // gestures do the same, and an undo writes this property
            // directly — a hook on any one of those would miss the others.
            if editingCrop, geometry.angle != oldValue.angle {
                repivotToCropCentre(from: oldValue)
                // …and then re-lock the view to the whole photograph, but
                // only once the rotation has ended: while a hand is still
                // turning it the scale must not change at all
                // (`beginRotation`/`endRotation`).
                if !rotationHeld { fitRotatedPhoto() }
            }
            layer2Dirty = true
            // While the crop tool is up the view stays on the whole frame, so
            // a drag does not make the picture jump under the handles. The
            // refit happens once, on leaving the tool.
            if !editingCrop { refreshLogicalSize() }
            needsDraw?()
        }
    }
    /// True while the crop tool is active: the canvas then shows the whole
    /// frame with the area outside the crop dimmed, rather than the cropped
    /// result. Capture One's behaviour, and the only way to judge a crop.
    var editingCrop = false {
        didSet {
            guard oldValue != editingCrop else { return }
            // Entering the tool pivots on the crop's own centre, so the
            // photo turns about the middle of the frame the user is looking
            // at. Leaving re-enters the tool's contract from scratch anyway.
            if editingCrop { cropPivot = geometry.centre }
            layer2Dirty = true
            refreshLogicalSize()
            // …and then **always** lock the view to the whole photograph.
            // `refreshLogicalSize` only has something to do when the logical
            // size changes, which is why entering the tool at 400 % with a
            // full-frame 0° crop used to arrive at 400 %.
            if editingCrop { fitRotatedPhoto() }
            needsDraw?()
        }
    }
    /// The crop tool's pivot, source-normalised (see `CanvasUniforms.pivot`).
    /// The canvas converts its drags through the same point, so a gesture and
    /// the picture it is dragging cannot disagree about where the centre is.
    var cropPivot = CGPoint(x: 0.5, y: 0.5) {
        didSet { if oldValue != cropPivot { needsDraw?() } }
    }

    /// The margin the crop tool's view keeps clear around the photograph, in
    /// view points. The crop is always inside the picture, so fitting the
    /// picture puts the frame on screen — and this is what keeps the grips,
    /// which sit half outside the frame, and the rotate zone outside it,
    /// reachable.
    static let cropLockMargin: CGFloat = 24

    /// Fit the view to the whole photograph, **as it is drawn**: the bounding
    /// box of its four corners in edit space (`Geometry.editBounds`), plus
    /// `margin` points clear all round.
    ///
    /// This is the crop tool's view. The photograph is turned about the pivot
    /// on screen, so at any non-zero angle it occupies a box larger than the
    /// frame — 1/cos θ taller on a 2:3 frame, and more across on a wide one —
    /// and fitting the frame cuts the picture's own corners off. Fitting the
    /// photograph fits the crop as well, whatever the angle is, because the
    /// crop only ever contains pixels of the photograph.
    ///
    /// Only `scale` and `offset` change: `viewport.image` stays the whole
    /// frame, so every mapping between view points, image points and edit
    /// space — and therefore every gesture — is exactly what it was.
    /// False when there is nothing to fit (no image, or the tool is not up).
    ///
    /// It invalidates the canvas itself. `onViewportChanged` alone is not
    /// enough and this is the whole bug of the first cut of it: the mirror
    /// update repaints the pill and the panel because they *read*
    /// `zoomPercent`, but nothing the canvas view reads changes, so its
    /// `updateNSView` never runs and the layer keeps presenting the old
    /// scale. The SwiftUI overlay on top — the frame, the grips, the thirds —
    /// derives from the same geometry and does update, so the two disagree on
    /// screen: the frame sits at the new fit around a photograph still drawn
    /// at the old one, until an unrelated event forces a repaint.
    @discardableResult
    func fitRotatedPhoto(margin: CGFloat = Renderer.cropLockMargin) -> Bool {
        guard editingCrop, let sourceSize else { return false }
        viewport.fit(toNormalised: geometry.editBounds(pivot: cropPivot, in: sourceSize), margin: margin)
        onViewportChanged?()
        needsDraw?()
        return true
    }

    /// True from the first event of a rotation until the input that produced
    /// it has ended — a canvas drag held down, or the Straighten slider
    /// between its press and its release. The view is **never** refitted while
    /// it is set: a picture that rescales under a hand still turning it is the
    /// thing this lock exists to stop. The refit happens once, at the end.
    private(set) var rotationHeld = false

    /// A rotation gesture has begun. Hold the view still until it ends.
    func beginRotation() { rotationHeld = true }

    /// The rotation input has ended: refit now, once, at the angle it ended
    /// on. Outside the crop tool this only clears the flag — the view there
    /// follows the crop, not the photograph.
    func endRotation() {
        rotationHeld = false
        fitRotatedPhoto()
    }

    /// Point the edit transform at the crop's centre again.
    ///
    /// The photo is drawn about the pivot, so an angle change with the pivot
    /// somewhere the user has since moved the crop away from would swing the
    /// whole picture around on screen. Moving the pivot back to the crop's
    /// centre first means the rotation happens where the user is looking —
    /// and every edit point shifts by the same `Geometry.pivotShift`, which
    /// the viewport is nudged by so nothing on screen jumps at all.
    ///
    /// The rule lives in `Geometry.repivot` so that a test can drive this
    /// exact step rather than a paraphrase of it. `old` is the generation
    /// being replaced, and its angle — not the new one — is what the shift is
    /// computed at; see the note there.
    private func repivotToCropCentre(from old: Geometry) {
        guard let sourceSize,
              let r = Geometry.repivot(from: old, to: geometry, pivot: cropPivot,
                                       in: sourceSize, scale: viewport.scale)
        else { return }
        cropPivot = r.pivot
        viewport.offset.x += r.offset.width
        viewport.offset.y += r.offset.height
        onViewportChanged?()
    }
    /// The live tier's pixel size — what the geometry is normalised against,
    /// and what `logicalSize(forSource:)` turns into the viewport's units.
    private(set) var sourceSize: CGSize?
    var layer2 = Layer2Uniforms() { didSet { layer2Dirty = true } }
    /// RFC-028: asked at encode time, of the texture being encoded. True for
    /// a Digital Intermediate, whose pixels are Cineon codes: the layer reads
    /// them through the DI view (`CineonLUT`) first, and Post-Dev then works
    /// in ProPhoto exactly as it does on a print.
    var layer2DecodesCineon: ((MTLTexture) -> Bool)?
    /// Set only inside `applyCineonView`, which decodes whatever the frame is.
    private var forceCineonDecode = false
    /// The DI view, the shipped ProPhoto `.cube`, loaded once.
    private lazy var cineonTable: MTLTexture? = CineonLUT.makeTexture(device: device)
    /// The masks, already packed. Set from `Session` whenever the mask list
    /// changes; at most `EditMask.maxCount`.
    var masks: [MaskUniform] = [] { didSet { layer2Dirty = true; needsDraw?() } }
    /// Index into `masks` of the one whose coverage is tinted red, or −1.
    /// Only one at a time: every mask's coverage at once is a red picture
    /// that says nothing about the one being edited.
    var maskOverlay: Int32 = -1 { didSet { if oldValue != maskOverlay { layer2Dirty = true; needsDraw?() } } }
    var onHistogram: (@MainActor ([Float]) -> Void)?
    var needsDraw: (@MainActor () -> Void)?
    /// Fired whenever the renderer itself moves the viewport — which
    /// `setLive` does when it takes a new frame's logical size, because a new
    /// image is fitted. Without it the zoom readout keeps whatever it computed
    /// against the *previous* image; with no image that is a 1×1 placeholder,
    /// and the pill read "Fit · 158,000 %".
    var onViewportChanged: (@MainActor () -> Void)?
    /// Incremented on every completed `draw(in:)`. The canvas cannot be seen
    /// by an offscreen test, but *whether it drew* can be, and that is the
    /// half that broke.
    private(set) var drawCount = 0

    /// The **drawable** format. `CAMetalLayer` accepts only a short list —
    /// bgra8Unorm(_srgb), rgba16Float, rgb10a2Unorm, bgr10a2Unorm and the xr
    /// variants — and setting anything else raises
    /// `CAMetalLayerInvalid: invalid pixel format`. `rgba16Unorm` (110) is a
    /// perfectly good *texture* format and is not on that list; it crashed the
    /// app on the first real launch. Float16 also matches UI-GUIDELINE §4.
    ///
    /// This does not change the colour rule: the layer's colour space is
    /// Display P3 and the values written are already P3-encoded, so ColorSync
    /// still performs exactly one transform. Float storage is not linear
    /// storage — the numbers are unchanged, only their container is.
    static let drawableFormat: MTLPixelFormat = .rgba16Float
    /// The **offscreen** format, for snapshots and export: 16-bit unorm, so
    /// `makeCGImage()` can hand the bytes to ImageIO without a conversion.
    static let offscreenFormat: MTLPixelFormat = .rgba16Unorm


    init?(device: MTLDevice? = MTLCreateSystemDefaultDevice(),
          arena: MemoryArena = MemoryArena(),
          scratchPool: Bool = FeatureFlags.scratchPool) {
        guard let device, let queue = device.makeCommandQueue() else { return nil }
        self.device = device
        self.queue = queue
        self.arena = arena
        self.scratchPool = scratchPool
        self.store = TextureStore(device: device, arena: arena)
        guard let lib = try? device.makeDefaultLibrary(bundle: Bundle(for: Renderer.self)),
              let l2 = lib.makeFunction(name: "layer2"),
              let xform = lib.makeFunction(name: "outputTransform"),
              let hist = lib.makeFunction(name: "histogram"),
              let geo = lib.makeFunction(name: "geometryResample"),
              let pairFn = lib.makeFunction(name: "pairComposite"),
              let vs = lib.makeFunction(name: "canvasVertex"),
              let fs = lib.makeFunction(name: "canvasFragment") else { return nil }
        do {
            layer2Pipeline = try device.makeComputePipelineState(function: l2)
            transformPipeline = try device.makeComputePipelineState(function: xform)
            histogramPipeline = try device.makeComputePipelineState(function: hist)
            geometryPipeline = try device.makeComputePipelineState(function: geo)
            pairPipeline = try device.makeComputePipelineState(function: pairFn)
            let rd = MTLRenderPipelineDescriptor()
            rd.vertexFunction = vs
            rd.fragmentFunction = fs
            rd.colorAttachments[0].pixelFormat = Renderer.drawableFormat
            quadPipelineDrawable = try device.makeRenderPipelineState(descriptor: rd)
            rd.colorAttachments[0].pixelFormat = Renderer.offscreenFormat
            quadPipelineOffscreen = try device.makeRenderPipelineState(descriptor: rd)
        } catch { return nil }
        guard let ct = store.makeCurveTable(),
              let hb = device.makeBuffer(length: 4 * 256 * 4, options: .storageModeShared),
              let sb = device.makeBuffer(length: 3 * MemoryLayout<UInt32>.size,
                                         options: .storageModeShared) else { return nil }
        curveTable = ct
        histogramBuffer = hb
        transformStats = sb
        super.init()
        store.upload(curves: CurveSet(), into: curveTable)
    }

    // MARK: inputs

    func setLive(_ texture: MTLTexture?, logical: CGSize? = nil) {
        log("setLive \(texture.map { "\($0.width)x\($0.height)" } ?? "nil"), needsDraw=\(needsDraw != nil)")
        let previous = live
        live = texture
        if texture == nil { showsFullRender = false; sourceSize = nil }
        layer2Dirty = true
        // `logical` is the live tier's source size, fixed per frame. The
        // first image of a frame passes it (and refits); later live prints
        // and every detail swap pass nil so the view does not move.
        if let logical { sourceSize = logical }
        else if sourceSize == nil, let texture { sourceSize = CGSize(width: texture.width, height: texture.height) }
        else if let texture, let previous { conformSourceSize(to: texture, previous: previous) }
        refreshLogicalSize()
        needsDraw?()
    }

    /// Keep the frame the viewport is expressed against in the proportion of
    /// the texture it is drawn from. A print of another shape than the last —
    /// a film edge's canvas, which grows with the format, the view and even
    /// the camera seed — would otherwise be drawn into the old rectangle,
    /// stretched. The scale from texture to frame pixels is kept (the tier
    /// has not changed), so a 1254 px canvas becoming 1250 px moves the view
    /// by that and no more. Within a pixel of the old shape nothing moves.
    private func conformSourceSize(to texture: MTLTexture, previous: MTLTexture) {
        // Framing a film edge shows the decode over the film print; the frame
        // is the decode's then, whatever print lands under it.
        guard !(editingCrop && showOriginal) else { return }
        guard let size = sourceSize, previous.width > 0, texture.height > 0 else { return }
        guard !Renderer.sameShape(size, CGSize(width: texture.width, height: texture.height)) else { return }
        let k = size.width / CGFloat(previous.width)
        sourceSize = CGSize(width: (CGFloat(texture.width) * k).rounded(),
                            height: (CGFloat(texture.height) * k).rounded())
    }

    /// Whether a frame of `size` draws a `texture`-sized image without
    /// stretching it by more than one texture pixel along either side.
    static func sameShape(_ size: CGSize, _ texture: CGSize) -> Bool {
        guard size.width > 0, size.height > 0, texture.width > 0, texture.height > 0 else { return true }
        let drawnHeight = texture.width * size.height / size.width
        return abs(drawnHeight - texture.height) <= 1
    }

    /// Re-express the viewport against whatever the output currently is — the
    /// whole frame while cropping, the crop's own size otherwise — and refit
    /// if that changed. `ViewportState.resize` fits on an image-size change,
    /// which is what makes leaving the crop tool land on the crop.
    func refreshLogicalSize() {
        guard let sourceSize else { return }
        let target = logicalSize(forSource: sourceSize)
        guard target != viewport.image else { return }
        viewport.resize(viewport: viewport.viewport, image: target)
        onViewportChanged?()
    }

    /// Put the frame's own-resolution render on screen. The viewport is
    /// unchanged: the draw scales the texture to the same on-screen rectangle.
    func setFullRender(_ texture: MTLTexture?) {
        fullRender = texture
        showsFullRender = texture != nil
        // The native render is the frame's own pixels, so when its shape is
        // not the frame's the frame is it (see `conformSourceSize`).
        if let texture, let size = sourceSize, !editingCrop || !showOriginal,
           !Renderer.sameShape(size, CGSize(width: texture.width, height: texture.height)) {
            sourceSize = CGSize(width: texture.width, height: texture.height)
            refreshLogicalSize()
        }
        layer2Dirty = true
        needsDraw?()
    }

    /// Show the preview-resolution print again without discarding the native
    /// render, so an edit that lands the same parameters back gets it for
    /// free.
    func hideFullRender() {
        guard showsFullRender else { return }
        showsFullRender = false
        layer2Dirty = true
        needsDraw?()
    }

    /// Discard the native render. Used when it can no longer be trusted: the
    /// parameters changed, or another frame is selected.
    func dropFullRender() {
        guard fullRender != nil || showsFullRender else { return }
        fullRender = nil
        showsFullRender = false
        layer2Dirty = true
        needsDraw?()
    }

    func setCurves(_ curves: CurveSet) {
        currentCurves = curves
        store.upload(curves: curves, into: curveTable)
        layer2Dirty = true
        needsDraw?()
    }

    var imageSize: CGSize? { base.map { CGSize(width: $0.width, height: $0.height) } }

    // MARK: Layer 2

    private func ensureAdjusted(for src: MTLTexture) -> MTLTexture? {
        if let a = adjusted, a.width == src.width, a.height == src.height { return a }
        adjusted = store.makeWritable(width: src.width, height: src.height)
        return adjusted
    }

    /// A 1×1×1 stand-in for the brush-raster array. Sampling an unbound
    /// texture is undefined, and a mask made only of closed-form components
    /// binds no raster — which is every mask today — so something has to be
    /// there. One texel of zero costs nothing and removes the branch from the
    /// binding code.
    private lazy var emptyRasterArray: MTLTexture? = {
        let d = MTLTextureDescriptor()
        d.textureType = .type2DArray
        d.pixelFormat = .r8Unorm
        d.width = 1; d.height = 1; d.arrayLength = 1
        d.usage = [.shaderRead]
        d.storageMode = .shared
        return device.makeTexture(descriptor: d)
    }()

    private func encodeLayer2(_ cb: MTLCommandBuffer, src: MTLTexture, dst: MTLTexture) {
        guard let enc = cb.makeComputeCommandEncoder() else { return }
        enc.setComputePipelineState(layer2Pipeline)
        enc.setTexture(src, index: 0)
        enc.setTexture(dst, index: 1)
        enc.setTexture(curveTable, index: 2)
        enc.setTexture(maskRasters ?? emptyRasterArray, index: 3)
        let decode = forceCineonDecode || (layer2DecodesCineon?(src) ?? false)
        var u = layer2
        u.inputDecode = decode ? 1 : 0
        enc.setTexture(cineonTable, index: 4)
        enc.setBytes(&u, length: MemoryLayout<Layer2Uniforms>.stride, index: 0)
        var list = Array(masks.prefix(EditMask.maxCount))
        var count = UInt32(list.count)
        var overlay = maskOverlay
        if list.isEmpty {
            // `setBytes` refuses a zero length, and the kernel reads nothing
            // when the count is zero.
            var dummy = MaskUniform()
            enc.setBytes(&dummy, length: MemoryLayout<MaskUniform>.stride, index: 1)
        } else {
            enc.setBytes(&list, length: MemoryLayout<MaskUniform>.stride * list.count, index: 1)
        }
        enc.setBytes(&count, length: MemoryLayout<UInt32>.size, index: 2)
        enc.setBytes(&overlay, length: MemoryLayout<Int32>.size, index: 3)
        let w = layer2Pipeline.threadExecutionWidth
        let h = max(1, layer2Pipeline.maxTotalThreadsPerThreadgroup / w)
        enc.dispatchThreads(MTLSize(width: dst.width, height: dst.height, depth: 1),
                            threadsPerThreadgroup: MTLSize(width: w, height: h, depth: 1))
        enc.endEncoding()
    }

    // MARK: the output transform — export and the proof only

    /// The output transform, which **the canvas does not run**.
    ///
    /// The working-space texture is what the canvas draws and what the layer
    /// says it is; ColorSync converts it for the display. This is the export's
    /// half, and the only half left: a file in another space needs a
    /// perceptual conversion of its own, and that is what it gets — once, per
    /// destination, into the recipe's space.
    ///
    /// (RFC-018 §2.4 built this for the canvas too. The user reversed that half
    /// on 2026-09-13 — "all displayed image in the main app page would be in
    /// ProPhoto RGB and macOS should be handling the color space management" —
    /// and D2 records the reversal with the objection that was raised and
    /// overruled. What that costs is measured: §7.2 found 0.0012 % of a neutral
    /// frame's pixels outside Display P3, 0.10 % with saturation at the top.)
    ///
    /// The counters are accumulated with atomics, so they have to start at
    /// zero — and only on the paths that read them, because a blit per draw is
    /// a blit per draw.
    private func clearTransformStats(_ cb: MTLCommandBuffer) {
        guard let blit = cb.makeBlitCommandEncoder() else { return }
        blit.fill(buffer: transformStats, range: 0..<transformStats.length, value: 0)
        blit.endEncoding()
    }

    private func encodeOutputTransform(_ cb: MTLCommandBuffer, src: MTLTexture, dst: MTLTexture,
                                       setup: OutputTransformSetup) {
        guard let enc = cb.makeComputeCommandEncoder() else { return }
        enc.setComputePipelineState(transformPipeline)
        enc.setTexture(src, index: 0)
        enc.setTexture(dst, index: 1)
        var u = setup.uniforms
        enc.setBytes(&u, length: MemoryLayout<OutputTransformUniforms>.stride, index: 0)
        enc.setBuffer(setup.cmax, offset: 0, index: 1)
        enc.setBuffer(transformStats, offset: 0, index: 2)
        let w = transformPipeline.threadExecutionWidth
        let h = max(1, transformPipeline.maxTotalThreadsPerThreadgroup / w)
        enc.dispatchThreads(MTLSize(width: dst.width, height: dst.height, depth: 1),
                            threadsPerThreadgroup: MTLSize(width: w, height: h, depth: 1))
        enc.endEncoding()
    }

    /// Run the transform and **wait** for it, returning the converted texture
    /// and the two counters.
    ///
    /// Export and the soft proof need both; the canvas path encodes without
    /// waiting and reads neither, because a stall per draw for two numbers
    /// nothing on screen uses would be a stall for nothing.
    func applyOutputTransform(to src: MTLTexture, setup: OutputTransformSetup,
                              into destination: MTLTexture? = nil)
        -> (texture: MTLTexture, stats: OutputTransformStats)? {
        guard let dst = destination ?? store.makeWritable(width: src.width, height: src.height),
              dst.width == src.width, dst.height == src.height,
              let cb = queue.makeCommandBuffer() else { return nil }
        clearTransformStats(cb)
        encodeOutputTransform(cb, src: src, dst: dst, setup: setup)
        cb.commit()
        cb.waitUntilCompleted()
        let p = transformStats.contents().bindMemory(to: UInt32.self, capacity: 3)
        let total = Double(max(1, src.width * src.height))
        return (dst, OutputTransformStats(movedFraction: Double(p[0]) / total,
                                          clippedFraction: Double(p[1]) / total,
                                          outsideFraction: Double(p[2]) / total))
    }

    /// Resample an image to an explicit pixel size (the export page's output
    /// size). Deliberately the **same** `geometryResample` kernel the canvas
    /// and the geometry pass use, with an identity geometry, rather than a
    /// CoreGraphics or `MTLBlitCommandEncoder` scale beside it: two
    /// resamplers are two chances to disagree about which pixel centre maps
    /// where, and the way that disagreement presents is an export that is
    /// subtly the wrong amount of sharp, which nothing checks.
    ///
    /// `Uniform()`'s default is inactive, and `geometryMap` returns its uv
    /// unchanged when it is — which is what makes this a plain resample.
    func applyResize(_ src: MTLTexture, width: Int, height: Int,
                     into destination: MTLTexture? = nil) -> MTLTexture? {
        guard width > 0, height > 0 else { return nil }
        guard width != src.width || height != src.height else { return src }
        guard let dst = destination ?? store.makeWritable(width: width, height: height),
              dst.width == width, dst.height == height,
              let cb = queue.makeCommandBuffer(), let enc = cb.makeComputeCommandEncoder() else { return nil }
        var u = Geometry.Uniform()
        enc.setComputePipelineState(geometryPipeline)
        enc.setTexture(src, index: 0)
        enc.setTexture(dst, index: 1)
        enc.setBytes(&u, length: MemoryLayout<Geometry.Uniform>.stride, index: 0)
        let tg = MTLSize(width: 16, height: 16, depth: 1)
        enc.dispatchThreadgroups(MTLSize(width: (width + 15) / 16, height: (height + 15) / 16, depth: 1),
                                 threadsPerThreadgroup: tg)
        enc.endEncoding()
        cb.commit()
        cb.waitUntilCompleted()
        return dst
    }

    private func encodeHistogram(_ cb: MTLCommandBuffer, src: MTLTexture) {
        guard let blit = cb.makeBlitCommandEncoder() else { return }
        blit.fill(buffer: histogramBuffer, range: 0..<histogramBuffer.length, value: 0)
        blit.endEncoding()
        guard let enc = cb.makeComputeCommandEncoder() else { return }
        enc.setComputePipelineState(histogramPipeline)
        enc.setTexture(src, index: 0)
        enc.setBuffer(histogramBuffer, offset: 0, index: 0)
        var stride = UInt32(max(1, Int((Double(src.width * src.height) / 200_000).squareRoot())))
        enc.setBytes(&stride, length: 4, index: 1)
        let gw = (src.width + Int(stride) - 1) / Int(stride), gh = (src.height + Int(stride) - 1) / Int(stride)
        let w = histogramPipeline.threadExecutionWidth
        let h = max(1, histogramPipeline.maxTotalThreadsPerThreadgroup / w)
        enc.dispatchThreads(MTLSize(width: gw, height: gh, depth: 1),
                            threadsPerThreadgroup: MTLSize(width: w, height: h, depth: 1))
        enc.endEncoding()
    }

    /// Publish the bins the `histogram` kernel just filled.
    ///
    /// **The axis is the working space's**, and that is a decision rather than
    /// an oversight. The bins are 256 even slices of the *encoded* value, and
    /// the texture they come from is the one the canvas draws — ProPhoto RGB,
    /// ROMM γ1.8. So mid-grey sits at bin 98 (`0.3857 × 256`), not at bin 118
    /// where an sRGB-encoded histogram would have put it, and the whole plot
    /// reads a little further left than it did.
    ///
    /// The alternative was to describe the *display* instead, by decoding to
    /// linear and re-encoding through the display's own curve. That was
    /// rejected because there is no longer such a thing: ColorSync converts
    /// per display and per profile, including on a screen that is not P3, so a
    /// histogram in that shape would be a guess about the monitor wearing the
    /// authority of a measurement. This one is a statement about the pixels the
    /// app holds, which is the thing a grade acts on and the thing an export
    /// will convert from.
    private func publishHistogram() {
        let p = histogramBuffer.contents().bindMemory(to: UInt32.self, capacity: 1024)
        var bins = [Float](repeating: 0, count: 1024)
        var maxv: Float = 1
        for i in 0..<1024 {
            let v = Float(p[i])
            bins[i] = v
            // Ignore the extreme bins for scaling: clipped black/white dominate.
            if i % 256 > 1 && i % 256 < 254 { maxv = max(maxv, v) }
        }
        for i in 0..<1024 { bins[i] = min(1, bins[i] / maxv) }
        onHistogram?(bins)
    }

    // MARK: drawing

    /// `SPEKTRAFILM_CANVAS_LOG=1` prints one line per draw. The canvas is the
    /// one surface no offscreen test can see (a `CAMetalLayer` renders nothing
    /// into `cacheDisplay`), so when it is blank this is how you find out
    /// which of the three possible reasons it is: no drawable, no base
    /// texture, or a base that never reached the encoder.
    static let logDraws = ProcessInfo.processInfo.environment["SPEKTRAFILM_CANVAS_LOG"] == "1"

    private func log(_ message: @autoclosure () -> String) {
        guard Renderer.logDraws else { return }
        FileHandle.standardError.write(Data("canvas: \(message())\n".utf8))
    }

    /// The canvas uniforms for one draw. `shown` may be the live texture or a
    /// detail texture several times its size; the viewport is always in live
    /// pixels, so the texture scale is the viewport's scale times the ratio
    /// of logical to texture pixels. Without that ratio a 5504 px detail
    /// render would draw 5.2× too large — which is exactly what the first
    /// capture of this path showed: a black canvas, because only a corner of
    /// the magnified image was on screen.
    private func canvasUniforms(shown: MTLTexture?, viewportSize: CGSize, backingScale: CGFloat) -> CanvasUniforms {
        var u = CanvasUniforms()
        u.viewportSize = SIMD2(Float(viewportSize.width), Float(viewportSize.height))
        guard let shown else { return u }
        // The viewport is in *output* logical pixels, so the sampling
        // transform is now the identity on them and the shader does the rest
        // in normalised space. That is what retires the old
        // logical-over-texture ratio: a 5504 px detail texture and a 1600 px
        // live one already occupy the same rectangle because they are both
        // sampled by uv, not by pixel.
        let output = max(viewport.image.width, 1)
        u.imageSize = SIMD2(Float(viewport.image.width), Float(viewport.image.height))
        u.offset = SIMD2(Float(viewport.offset.x * backingScale), Float(viewport.offset.y * backingScale))
        u.scale = Float(viewport.scale * backingScale)
        // Source texture pixels actually spanned by the output, so the
        // sampler choice survives both the detail-tier swap and the crop.
        let spanned = editingCrop ? CGFloat(shown.width) : CGFloat(shown.width) * geometry.crop.width
        u.magnification = Float(viewport.scale * backingScale * output / max(spanned, 1))
        u.geometry = geometry.uniform(for: CGSize(width: shown.width, height: shown.height))
        u.editingCrop = editingCrop ? 1 : 0
        u.compare = compareMode.rawValue
        u.compareSplit = comparePosition
        u.pivot = SIMD2(Float(cropPivot.x), Float(cropPivot.y))
        return u
    }

    /// The size the viewport should be expressed against for a given source:
    /// the whole frame while the crop is being edited, the crop's output
    /// otherwise. Fit and zoom then mean what they say in both states.
    func logicalSize(forSource size: CGSize) -> CGSize {
        editingCrop ? size : geometry.outputSize(for: size)
    }

    func draw(in view: MTKView) {
        // Counted here, before the drawable guard: the question a test needs
        // answered is whether the invalidation reached the delegate at all.
        // An off-screen window legitimately vends no drawable.
        drawCount += 1
        guard let drawable = view.currentDrawable, let rpd = view.currentRenderPassDescriptor,
              let cb = queue.makeCommandBuffer() else {
            log("no drawable (size \(view.drawableSize), window \(view.window != nil))")
            return
        }
        var shown: MTLTexture? = nil
        if let base {
            if showOriginal, let original {
                shown = original
            } else if let dst = ensureAdjusted(for: base) {
                if layer2Dirty {
                    encodeLayer2(cb, src: base, dst: dst)
                    layer2Dirty = false
                    // The histogram is taken of **what the canvas draws** —
                    // the working-space texture — now that there is no
                    // converted one to take it of. What that means for its
                    // axis is recorded on `publishHistogram`.
                    if !histogramInFlight {
                        histogramInFlight = true
                        encodeHistogram(cb, src: dst)
                        cb.addCompletedHandler { [weak self] _ in
                            Task { @MainActor in
                                self?.histogramInFlight = false
                                self?.publishHistogram()
                            }
                        }
                    }
                }
                shown = dst
            }
        }
        // Left of the split and under Space. The same texture the right half is
        // drawn from — both are the working space, so the split compares two
        // renderings and not two colour spaces.
        let before = original ?? shown
        let bs = Float(view.window?.backingScaleFactor ?? viewport.backingScale)
        var u = canvasUniforms(shown: shown, viewportSize: view.drawableSize, backingScale: CGFloat(bs))
        // The timestamp is not decoration: "the canvas twitches" is a question
        // about *when* frames reach the screen, and a log of states without
        // times cannot answer it. Milliseconds since the process started, so
        // the intervals are the frame intervals.
        let t = ProcessInfo.processInfo.systemUptime
        log(String(format: "t=%.6f base=%@ shown=%@ full=%@ scale=%f offset=(%.2f, %.2f) " +
                   "drawable=(%.0f, %.0f) bounds=(%.2f, %.2f) vp=(%.2f, %.2f) bs=%.1f",
                   t, base.map { "\($0.width)x\($0.height)" } ?? "nil", "\(shown != nil)",
                   "\(showsFullRender)", viewport.scale, viewport.offset.x, viewport.offset.y,
                   view.drawableSize.width, view.drawableSize.height,
                   view.bounds.width, view.bounds.height,
                   viewport.viewport.width, viewport.viewport.height,
                   view.window?.backingScaleFactor ?? -1))
        rpd.colorAttachments[0].loadAction = .clear
        rpd.colorAttachments[0].clearColor = MTLClearColor(red: Double(u.surroundGray), green: Double(u.surroundGray), blue: Double(u.surroundGray), alpha: 1)
        guard let enc = cb.makeRenderCommandEncoder(descriptor: rpd) else { return }
        if let shown {
            enc.setRenderPipelineState(quadPipelineDrawable)
            enc.setFragmentTexture(shown, index: 0)
            // Always bound, even when nothing is being compared: an unbound
            // fragment texture is a sampling of undefined memory the moment a
            // branch is mispredicted into, and "the compare flag is off" is
            // not a guarantee the GPU makes.
            enc.setFragmentTexture(before, index: 1)
            enc.setFragmentBytes(&u, length: MemoryLayout<CanvasUniforms>.stride, index: 0)
            enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 6)
        }
        enc.endEncoding()
        cb.present(drawable)
        cb.commit()
    }

    // MARK: offscreen (export, snapshot, tests)

    /// Run Layer 2 over any texture synchronously. Used by export at full
    /// resolution and by the tests.
    func applyLayer2(to src: MTLTexture, uniforms: Layer2Uniforms? = nil,
                     into destination: MTLTexture? = nil) -> MTLTexture? {
        guard let dst = destination ?? store.makeWritable(width: src.width, height: src.height),
              dst.width == src.width, dst.height == src.height,
              let cb = queue.makeCommandBuffer() else { return nil }
        let saved = layer2
        if let uniforms { layer2 = uniforms }
        encodeLayer2(cb, src: src, dst: dst)
        layer2 = saved
        cb.commit()
        cb.waitUntilCompleted()
        return dst
    }

    /// The curves the canvas is drawing with (`setCurves`), so an offscreen
    /// grade with other curves can put them back.
    private var currentCurves = CurveSet()

    /// One grade over a texture, its curves included, without disturbing the
    /// canvas's own: a half-frame pair grades each frame by itself.
    func applyAdjustments(_ adjustments: Adjustments, to src: MTLTexture) -> MTLTexture? {
        store.upload(curves: adjustments.curves, into: curveTable)
        defer { store.upload(curves: currentCurves, into: curveTable); layer2Dirty = true }
        return applyLayer2(to: src, uniforms: adjustments.uniforms)
    }

    /// `base` with each frame's rectangle taken from that frame's own texture
    /// (nil: the base's). Rectangles are normalised, y down; all three
    /// textures are the same size.
    func compositePair(base: MTLTexture, first: MTLTexture?, firstRect: CGRect,
                       second: MTLTexture?, secondRect: CGRect) -> MTLTexture? {
        let w = base.width, h = base.height
        func fits(_ t: MTLTexture?) -> Bool { t.map { $0.width == w && $0.height == h } ?? true }
        guard fits(first), fits(second),
              let dst = store.makeWritable(width: w, height: h),
              let cb = queue.makeCommandBuffer(), let enc = cb.makeComputeCommandEncoder() else { return nil }
        func px(_ r: CGRect) -> SIMD4<Float> {
            SIMD4(Float(r.minX) * Float(w), Float(r.minY) * Float(h), Float(r.maxX) * Float(w), Float(r.maxY) * Float(h))
        }
        var u = PairRects(a: px(firstRect), b: px(secondRect), feather: 1.5,
                          useA: first == nil ? 0 : 1, useB: second == nil ? 0 : 1, pad: 0)
        enc.setComputePipelineState(pairPipeline)
        enc.setTexture(base, index: 0)
        enc.setTexture(first ?? base, index: 1)
        enc.setTexture(second ?? base, index: 2)
        enc.setTexture(dst, index: 3)
        enc.setBytes(&u, length: MemoryLayout<PairRects>.stride, index: 0)
        let tg = MTLSize(width: 16, height: 16, depth: 1)
        enc.dispatchThreadgroups(MTLSize(width: (w + 15) / 16, height: (h + 15) / 16, depth: 1),
                                 threadsPerThreadgroup: tg)
        enc.endEncoding()
        cb.commit()
        cb.waitUntilCompleted()
        return dst
    }

    /// The kernel's uniform (`Shaders.metal`, `PairRects`).
    private struct PairRects {
        var a: SIMD4<Float>, b: SIMD4<Float>
        var feather: Float, useA: Float, useB: Float, pad: Float
    }

    /// A Digital Intermediate texture (Cineon codes) through the DI view and
    /// nothing else — no grade, no mask. The DI export's preview page.
    func applyCineonView(to src: MTLTexture) -> MTLTexture? {
        var viewOnly = Layer2Uniforms()
        viewOnly.enabled = 0
        let savedMasks = masks
        forceCineonDecode = true
        masks = []
        defer { forceCineonDecode = false; masks = savedMasks }
        return applyLayer2(to: src, uniforms: viewOnly)
    }

    /// Apply crop, straighten, quarter turns and flips to a texture at its
    /// own resolution, through the same `geometryMap` the canvas draws with.
    /// Export calls this; nothing else needs to, because the canvas applies
    /// the geometry while sampling rather than by making a second texture.
    func applyGeometry(_ g: Geometry, to src: MTLTexture,
                       into destination: MTLTexture? = nil) -> MTLTexture? {
        guard !g.isIdentity else { return src }
        let srcSize = CGSize(width: src.width, height: src.height)
        let out = g.outputSize(for: srcSize)
        let w = Int(out.width), h = Int(out.height)
        guard w > 0, h > 0,
              let dst = destination ?? store.makeWritable(width: w, height: h),
              dst.width == w, dst.height == h,
              let cb = queue.makeCommandBuffer(), let enc = cb.makeComputeCommandEncoder() else { return nil }
        var u = g.uniform(for: srcSize)
        enc.setComputePipelineState(geometryPipeline)
        enc.setTexture(src, index: 0)
        enc.setTexture(dst, index: 1)
        enc.setBytes(&u, length: MemoryLayout<Geometry.Uniform>.stride, index: 0)
        let tg = MTLSize(width: 16, height: 16, depth: 1)
        enc.dispatchThreadgroups(MTLSize(width: (w + 15) / 16, height: (h + 15) / 16, depth: 1),
                                 threadsPerThreadgroup: tg)
        enc.endEncoding()
        cb.commit()
        cb.waitUntilCompleted()
        return dst
    }

    /// Render the canvas exactly as the window would show it, into an image.
    /// The snapshot harness uses this for the centre of the window.
    func renderOffscreen(size: CGSize, backingScale: CGFloat) -> MTLTexture? {
        let w = Int(size.width * backingScale), h = Int(size.height * backingScale)
        guard w > 0, h > 0, let target = store.makeWritable(width: w, height: h, format: Renderer.offscreenFormat),
              let cb = queue.makeCommandBuffer() else { return nil }
        var shown: MTLTexture? = nil
        // The same swap `draw` makes while Space is held, so a capture of
        // "show original" shows the original rather than the print.
        if base != nil, showOriginal, let original {
            shown = original
        } else if let base, let dst = ensureAdjusted(for: base) {
            encodeLayer2(cb, src: base, dst: dst)
            layer2Dirty = false
            shown = dst
            encodeHistogram(cb, src: dst)
        }
        let before = original ?? shown
        var u = canvasUniforms(shown: shown, viewportSize: CGSize(width: w, height: h), backingScale: backingScale)
        let rpd = MTLRenderPassDescriptor()
        rpd.colorAttachments[0].texture = target
        rpd.colorAttachments[0].loadAction = .clear
        rpd.colorAttachments[0].storeAction = .store
        rpd.colorAttachments[0].clearColor = MTLClearColor(red: Double(u.surroundGray), green: Double(u.surroundGray), blue: Double(u.surroundGray), alpha: 1)
        guard let enc = cb.makeRenderCommandEncoder(descriptor: rpd) else { return nil }
        if let shown {
            enc.setRenderPipelineState(quadPipelineOffscreen)
            enc.setFragmentTexture(shown, index: 0)
            enc.setFragmentTexture(before, index: 1)
            enc.setFragmentBytes(&u, length: MemoryLayout<CanvasUniforms>.stride, index: 0)
            enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 6)
        }
        enc.endEncoding()
        cb.commit()
        cb.waitUntilCompleted()
        if shown != nil, !showOriginal { publishHistogram() }
        return target
    }
}

extension MTLTexture {
    /// Read an rgba16Unorm texture back as a CGImage — **no conversion**. The
    /// bytes are what they are; the tag says which space that is.
    ///
    /// `space` is **the space the texture is in**, and it defaults to the
    /// working space because that is what the canvas holds. Getting it wrong is
    /// the quietest failure in the app — a ProPhoto picture wearing a P3 tag
    /// shows as a washed-out canvas and no error anywhere — so a caller that
    /// has converted passes its target explicitly (export does, and the DI
    /// package passes device RGB because its pixels are normalised film
    /// densities rather than colours; see `Exporter`).
    func makeCGImage(space: CGColorSpace = ImageDecoder.workingSpace ?? ImageDecoder.displayP3) -> CGImage? {
        guard pixelFormat == .rgba16Unorm else { return nil }
        let bpr = width * 8
        var data = Data(count: bpr * height)
        data.withUnsafeMutableBytes { raw in
            getBytes(raw.baseAddress!, bytesPerRow: bpr, from: MTLRegionMake2D(0, 0, width, height), mipmapLevel: 0)
        }
        guard let provider = CGDataProvider(data: data as CFData) else { return nil }
        return CGImage(width: width, height: height, bitsPerComponent: 16, bitsPerPixel: 64, bytesPerRow: bpr,
                       space: space,
                       bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipLast.rawValue | CGBitmapInfo.byteOrder16Little.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)
    }

    /// Raw 16-bit RGBA bytes, top row first.
    func rgba16Bytes() -> Data {
        let bpr = width * 8
        var data = Data(count: bpr * height)
        data.withUnsafeMutableBytes { raw in
            getBytes(raw.baseAddress!, bytesPerRow: bpr, from: MTLRegionMake2D(0, 0, width, height), mipmapLevel: 0)
        }
        return data
    }
}
