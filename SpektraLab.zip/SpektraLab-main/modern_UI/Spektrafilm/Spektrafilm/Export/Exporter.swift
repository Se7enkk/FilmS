//  Exporter.swift — delivery.
//
//  Two routes (frontend SPEC §6):
//    - finished: JPEG, PNG 8-bit, TIFF 16-bit — Display P3, Layer 2 baked in,
//      cropped, straightened and turned. The engine renders the print at full
//      resolution into a texture; the client applies Layer 2 and the geometry
//      in Metal and writes through ImageIO with a P3 tag.
//    - Digital Intermediate (RFC-028): the frame's DI as Kodak Cineon log,
//      16-bit TIFF, untagged, for any negative whatever paper the canvas
//      shows — plus the two DI-view `.cube` files beside it, once per folder.
//      Post-Dev does not apply; the DI is the master a grade starts from.
//
//  A frame the print list has on the Digital Intermediate exports its *view*
//  through the finished route like any print: the canvas reads the DI through
//  the shipped view LUT, Post-Dev applies in ProPhoto, and the recipe's colour
//  space is honoured.
//
//  Filenames: `<original>_<film>_<paper>.<ext>` in `<source dir>/_prints/`;
//  a DI is `<stem>_DI.tif`, so it can share a folder with a finished TIFF
//  (`ExportRecipe.destinationPath`).

import AppKit
import Foundation
import ImageIO
import Metal
import UniformTypeIdentifiers

enum ExportFormat: String, CaseIterable, Identifiable, Sendable {
    case jpeg = "JPEG", png = "PNG 8-bit", tiff = "TIFF 16-bit", di = "DI package"
    var id: String { rawValue }
    var ext: String { switch self { case .jpeg: "jpg"; case .png: "png"; case .tiff: "tif"; case .di: "tif" } }
    var utType: UTType { switch self { case .jpeg: .jpeg; case .png: .png; case .tiff, .di: .tiff } }
    var note: String {
        switch self {
        case .jpeg: "Display P3, quality 0.95. Adjustments baked in."
        case .png: "Display P3, 8-bit lossless. Adjustments baked in."
        case .tiff: "Display P3, 16-bit. Adjustments baked in; headroom is the scan margin only."
        case .di: "Negative density TIFF + print .cube. For grading under the print LUT in Photoshop."
        }
    }
}

@MainActor
enum Exporter {
    struct Result: Sendable {
        let urls: [URL]
        /// What to tell the user about this export beyond its paths. `var`
        /// because the colour fallback's reason is appended to whatever the
        /// route itself produced (RFC-018 §5.4: a substitution is never
        /// silent).
        var note: String?
        /// The EV the meter applied to the render this was written from.
        /// Carried out of the render so the export record and the job log can
        /// say which exposure produced the file (RFC-015 P.1's invariant, in
        /// the field).
        var appliedEV: Double?
        var pixels: (w: Int, h: Int)?
    }

    /// What one export produced.
    ///
    /// `skipped` is a real outcome, not an error: a recipe set to skip an
    /// existing file did exactly what it was asked to, and reporting that as
    /// a thrown error would put "the export failed" in front of a user whose
    /// export did not fail.
    enum Outcome: Sendable {
        case wrote(urls: [URL], note: String?, fellBackToDisplayP3: Bool)
        case skipped(URL)

        var urls: [URL] {
            switch self {
            case .wrote(let urls, _, _): urls
            case .skipped: []
            }
        }
    }

    /// The legacy destination: the default recipe's answer.
    ///
    /// Kept because it is the one place the *old* naming is written down, and
    /// `PrintLUTTests.testTheExportFilenames` pins it. It delegates rather
    /// than duplicating the rule, so the default recipe and this cannot drift
    /// — if they ever disagree, that test is what says so.
    static func destination(for source: URL, params: FilmParams, format: ExportFormat) -> URL {
        var recipe = ExportRecipe()
        recipe.format = format
        let context = NamingRule.Context(
            originalName: source.deletingPathExtension().lastPathComponent,
            filmStock: params.filmStock, printStock: params.printStock,
            pixelSize: .zero, counter: 1, date: Date())
        // `.overwrite` so this stays a pure function of its arguments: the
        // suffix policy would make it depend on what is already on disk, and
        // this one is used to *describe* a destination, not to claim it.
        recipe.existing = .overwrite
        return recipe.destination(for: source, context: context)
            ?? source.deletingLastPathComponent().appending(path: "_prints")
                     .appending(path: "\(source.deletingPathExtension().lastPathComponent).\(format.ext)")
    }

    /// One export, and the record of its own making (RFC-016 §3 `export`,
    /// §11.4's job log).
    ///
    /// The job log is written **beside the output**, always — succeeded or
    /// failed. That is the point of it: a folder of exports then carries the
    /// evidence of how each one was made, and a failure carries its own
    /// explanation rather than leaving a missing file and a shrug.
    static func export(session: Session, recipe: ExportRecipe,
                       context: NamingRule.Context, sessionID: String) async throws -> Outcome {
        guard let source = session.selection else { throw ExportError.nothingOpen }
        // A pair with an empty hole is not exported (answer B9).
        if let pair = session.pair, !pair.isComplete { throw ExportError.incompletePair }
        let format = recipe.format
        // The directory is created here rather than while *describing* a
        // destination: this is the only place that can tell the user it could
        // not be, and a recipe pointed at an unmounted volume must say so
        // rather than quietly writing somewhere else.
        let dir = recipe.directory(for: source)
        do {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        } catch {
            throw ExportError.directory(dir, error.localizedDescription)
        }
        guard let out = recipe.destination(for: source, context: context) else {
            // `.skip`, and the file is already there. Recorded, because "why
            // is there no new file" is a question the log should answer.
            session.log.info(.export, "export skipped", [
                .init("reason", "exists"),
                .init("frame", source.lastPathComponent),
                .init("recipe", recipe.name),
            ])
            let existing = recipe.destinationPath(for: source, context: context,
                                                  stem: recipe.naming.stem(context))
            return .skipped(existing)
        }
        // The DI package's file sits in a folder of its own
        // (`ExportRecipe.destinationPath`), so the leaf is created here too,
        // in the same place and for the same reason as `dir`: this is the only
        // site that can tell the user a directory could not be made.
        let leaf = out.deletingLastPathComponent()
        do {
            try FileManager.default.createDirectory(at: leaf, withIntermediateDirectories: true)
        } catch {
            throw ExportError.directory(leaf, error.localizedDescription)
        }
        // The job log goes beside the **export**, and for a package the export
        // is the folder: writing it beside the file would put a third thing
        // inside a package the user asked to be one TIFF and one cube. One
        // level up is still "beside" — the same `_prints/` folder every other
        // export's log lands in, under the same name it has today.
        let logAnchor = out
        // Opt-in since 2026-09-26 (`Diagnostics.writeExportJobLog`). The job
        // is still assembled either way: it costs nothing, and the session
        // log's `export` record is built beside it.
        let writesJobLog = session.diagnostics.writeExportJobLog
        let (target, _, fellBack, fellBackReason) = resolveTarget(recipe)
        var job = JobLog()
        job.note(.info, "export.start", jobHeader(session: session, recipe: recipe, out: out,
                                                  fellBack: fellBack))
        if let fellBackReason { job.note(.warn, "export.colour_fallback", [.init("why", fellBackReason)]) }
        let started = Date()
        do {
            var result = format == .di
                ? try await exportDigitalIntermediate(session: session, to: out)
                : try await exportPrint(session: session, to: out, format: format,
                                        quality: recipe.quality, recipe: recipe,
                                        sessionID: sessionID,
                                        sourceEXIF: session.decoded?.sourceEXIF)
            // The fallback's reason, if the route did not have one of its own.
            // Merged rather than set, because the DI route has a note of its
            // own (a film/paper mismatch) and losing it to a colour note would
            // be trading one silent substitution for another.
            if let fellBackReason, format != .di {
                result.note = result.note.map { "\($0) \(fellBackReason)" } ?? fellBackReason
            }
            let elapsed = Date().timeIntervalSince(started) * 1000
            for url in result.urls {
                job.note(.info, "export.file", [.init("path", url.lastPathComponent)])
            }
            job.note(.info, "export.done", [
                .init("elapsed_ms", elapsed),
                .init("files", result.urls.count),
                .init("ev", result.appliedEV ?? Double.nan),
            ])
            if writesJobLog { try? job.write(beside: logAnchor) }
            noteExport(session, recipe: recipe, result: result, elapsedMs: elapsed,
                       fellBack: fellBack, job: writesJobLog ? job : nil)
            // §3: after an export is a memory boundary — the full-tier render
            // it just made is the biggest thing the app allocates.
            session.sampleMemory("export")
            return .wrote(urls: result.urls, note: result.note, fellBackToDisplayP3: fellBack)
        } catch {
            job.note(.error, "export.failed", [
                .init("elapsed_ms", Date().timeIntervalSince(started) * 1000),
                .init("error", "\(error)"),
                .init("raw", EngineMessage.technical(error)),
            ])
            if writesJobLog { try? job.write(beside: logAnchor) }
            // A stopped batch is the person's decision, not a failure to
            // report back to them as one.
            if !(error is CancellationError) {
                session.noteFailure(error, operation: "export", frame: source.lastPathComponent)
            }
            throw error
        }
    }

    /// §3 `export`: destination format, bit depth, colour space, pixels,
    /// elapsed, and the applied EV — "so an export can be reconciled with the
    /// canvas that was approved".
    private static func noteExport(_ session: Session, recipe: ExportRecipe, result: Result,
                                   elapsedMs: Double, fellBack: Bool, job: JobLog?) {
        let format = recipe.format
        var fields: [LogField] = [
            .init("format", format.rawValue),
            .init("ext", format.ext),
            .init("bit_depth", depth(format)),
            .init("color_space", colourSpace(recipe)),
            // The file has a second picture in it, and the record of what was
            // written should say so: a preview is about a tenth of the file,
            // and "why is this TIFF bigger than that one" is a question this
            // log exists to answer.
            .init("preview_page", writesPreviewPage(recipe)),
            .init("recipe", recipe.name),
            .init("profile_fell_back", fellBack),
            .init("elapsed_ms", elapsedMs),
            .init("files", result.urls.count),
            .init("frame", session.selection?.lastPathComponent ?? "-"),
        ]
        if job != nil {
            fields.append(.init("job_log", JobLog.url(beside: result.urls[0]).lastPathComponent))
        }
        if let pixels = result.pixels {
            fields.append(.init("w", pixels.w)); fields.append(.init("h", pixels.h))
            fields.append(.init("px", pixels.w * pixels.h))
        }
        if let ev = result.appliedEV { fields.append(.init("ev", ev)) }
        session.log.info(.export, "export", fields)
    }

    /// The space this export will actually be in: a `CGColorSpace`, the
    /// engine's name for it, and — when those are not what the recipe asked
    /// for — why, in words a user can act on.
    ///
    /// There are two ways to land on Display P3 and they are different
    /// failures. A profile that is not on this machine is the one
    /// `resolvedColorSpace()` has always reported. A profile that *is*
    /// installed but has no baked colour space in the engine is new with
    /// RFC-018: the transform cannot be built for it, and since §2.4 retired
    /// Core Graphics' clip there is nothing left to fall back *to*. Neither is
    /// silent — §5.4's rule, and the reason this returns a sentence rather
    /// than a bool.
    /// Not private: `SoftProof` resolves its destination through this same
    /// function, because a proof of a space other than the file's is
    /// decoration (RFC-018 §7.6).
    static func resolveTarget(_ recipe: ExportRecipe)
        -> (space: CGColorSpace, name: String, fellBack: Bool, reason: String?) {
        // Resolved once: `.installed` reads an ICC profile off disk, and some
        // of those are a megabyte.
        let resolved = recipe.resolvedColorSpace().space
        if let resolved {
            if let name = ColourManagement.engineName(for: resolved) {
                return (resolved, name, false, nil)
            }
            let asked = ColorSpaceCatalog.name(for: recipe.colorSpace) ?? "The recipe's profile"
            return (ImageDecoder.displayP3, "Display P3", true,
                    "\(asked) has no colour space in the engine, so the perceptual transform cannot be built for it. The file is in Display P3.")
        }
        // `resolvedColorSpace` returned nil: either the format carries no
        // colour at all (the DI package — handled by its own route, and this
        // value is never used) or the profile could not be read.
        guard recipe.format.takesColorSpace else {
            return (CGColorSpaceCreateDeviceRGB(), "device RGB (density)", false, nil)
        }
        return (ImageDecoder.displayP3, "Display P3", true,
                "The recipe's profile is not on this machine. The file is in Display P3.")
    }

    private static func depth(_ format: ExportFormat) -> Int {
        switch format {
        case .jpeg, .png: 8
        case .tiff, .di: 16
        }
    }

    /// What the log and the job log call the export's colour space. The DI
    /// is deliberately untagged: its channels are Cineon codes, not colours
    /// (see `exportDigitalIntermediate`), and it has no profile to name.
    private static func colourSpace(_ recipe: ExportRecipe) -> String {
        guard recipe.format.takesColorSpace else { return "Cineon log, ProPhoto primaries (untagged)" }
        return ColorSpaceCatalog.name(for: recipe.colorSpace) ?? "unresolved profile"
    }

    /// What the job log's header record carries: the recipe, in one place, so
    /// a folder of exports can be read without the app that made them.
    private static func jobHeader(session: Session, recipe: ExportRecipe, out: URL,
                                  fellBack: Bool) -> [LogField] {
        let p = session.params
        return [
            .init("recipe", recipe.name),
            .init("format", recipe.format.rawValue),
            .init("bit_depth", depth(recipe.format)),
            .init("color_space", colourSpace(recipe)),
            .init("profile_fell_back", fellBack),
            .init("destination", out.lastPathComponent),
            .init("directory", out.deletingLastPathComponent().path),
            .init("film", p.filmStock),
            .init("print", p.printStock),
            .init("exposure_comp_ev", session.sidecar.solvedEV ?? Double.nan),
            .init("y_shift", p.yFilterShift),
            .init("m_shift", p.mFilterShift),
            .init("layer2", session.adjustments.enabled),
            .init("render_core", session.renderCore ?? "unreported"),
            .init("engine", session.diagnostics.engineVersion ?? "unknown"),
            .init("app", Diagnostics.bundleInfo.version),
            .init("marker", "job"),
        ]
    }

    /// The file's pixels, before anything is written: **render, grade, frame,
    /// size, convert** — in that order, which is the whole of RFC-018's export
    /// claim.
    ///
    /// This is the one chain. `exportPrint` writes what it returns and
    /// `Session.softProof` derives its display image from the same result, so
    /// "the proof is the file" (§7.6) is a property of the code rather than of
    /// two sequences of the same steps that happen to agree — which is what it
    /// was, and what made the claim conditional on the canvas happening to
    /// hold the frame's own pixels.
    ///
    /// The source is a **full-tier reprint**, the same request the export
    /// makes: the proof cannot be bounded by whatever tier the canvas is
    /// showing, because that is not what gets written. `.export` reuses the
    /// working negative when one is warm and runs the film side when it is
    /// not.
    ///
    /// The recipe's own output size, when it names one, is applied **before**
    /// the transform — so the transform and its clip statistics run on the
    /// pixels that actually reach the file rather than on a larger set that
    /// was resampled away, and so the proof of a resized recipe is that size
    /// too.
    ///
    /// Throws `CancellationError` if the task is cancelled — a superseded
    /// proof is not a stale picture, it is no picture.
    static func filePixels(session: Session, recipe: ExportRecipe, sessionID: String) async throws -> Rendered {
        // A frame on the Digital Intermediate comes out of the engine as Cineon
        // codes; the Layer 2 pass below reads them through the DI view first
        // (`Renderer.layer2DecodesCineon`), so from there on it is ProPhoto
        // like any print.
        let (target, _, _, _) = resolveTarget(recipe)
        let outcome = try await session.client.render(
            .export, RenderRequest(sessionID: sessionID, tier: "full"))
        try Task.checkCancellation()
        guard var full = outcome.texture else { throw ExportError.noPixels }
        // A pair: each frame printed and graded as its own, cut together, as
        // the canvas shows it. The grade below is then none.
        if session.pair != nil, let layered = await session.pairLayered(base: full, tier: "full") {
            full = layered
        }
        try Task.checkCancellation()

        func destination(width: Int, height: Int)
            throws -> (texture: MTLTexture, scratch: TextureStore.Scratch?) {
            if session.renderer.scratchPool {
                guard let scratch = session.renderer.store.borrowWritable(width: width,
                                                                          height: height)
                else { throw ExportError.noPixels }
                return (scratch.texture, scratch)
            }
            guard let texture = session.renderer.store.makeWritable(width: width, height: height)
            else { throw ExportError.noPixels }
            return (texture, nil)
        }

        let (adjustedDestination, adjustedScratch) = try destination(width: full.width,
                                                                     height: full.height)
        guard let adjusted = session.renderer.applyLayer2(to: full,
                                                          uniforms: session.exportAdjustments.uniforms,
                                                          into: adjustedDestination)
            else { throw ExportError.noPixels }
        var current = adjusted
        var currentScratch = adjustedScratch
        // Crop, straighten, quarter turns and flips, through the same
        // `geometryMap` the canvas samples with — not a CoreGraphics
        // transform written a second time. The old path cropped with
        // `CGImage.cropping` and could not rotate at all, so a straightened
        // frame exported unstraightened and nothing in the app said so.
        // With a film edge the engine's print is the film canvas, already cut
        // from the crop (`Session.printGeometry`), and is written whole.
        let geometry = session.printGeometry
        if !geometry.isIdentity {
            let out = geometry.outputSize(for: CGSize(width: current.width,
                                                      height: current.height))
            let (framedDestination, framedScratch) = try destination(width: Int(out.width),
                                                                     height: Int(out.height))
            guard session.renderer.applyGeometry(geometry, to: current,
                                                 into: framedDestination) != nil
            else { throw ExportError.noPixels }
            currentScratch?.giveBack()
            current = framedDestination
            currentScratch = framedScratch
        }
        // The page's output size, through the geometry pass's own resampler.
        // Asked for against the pixels in hand — after the crop and the
        // straighten — so the long edge is the long edge of the picture that
        // is actually being written, and the other side follows from it
        // rather than from whatever a second field was left holding.
        if let outputSize = recipe.pixelSize(for: CGSize(width: current.width,
                                                         height: current.height)) {
            let w = Int(outputSize.width.rounded()), h = Int(outputSize.height.rounded())
            if w != current.width || h != current.height {
                let (resizedDestination, resizedScratch) = try destination(width: w, height: h)
                guard session.renderer.applyResize(current, width: w, height: h,
                                                   into: resizedDestination) != nil
                else { throw ExportError.noPixels }
                currentScratch?.giveBack()
                current = resizedDestination
                currentScratch = resizedScratch
            }
        }
        // The one conversion, at the end, out of the working space and into
        // the destination — the same kernel the canvas and the soft proof run.
        let (setup, problem) = await ColourManagement.setup(client: session.client,
                                                            source: session.workingSpaceName,
                                                            target: target,
                                                            device: session.renderer.device)
        guard let setup else { throw ExportError.colourSpace(problem ?? "the engine refused it") }
        let (convertedDestination, convertedScratch) = try destination(width: current.width,
                                                                       height: current.height)
        guard let converted = session.renderer.applyOutputTransform(to: current, setup: setup,
                                                                    into: convertedDestination)
        else { throw ExportError.noPixels }
        currentScratch?.giveBack()
        return Rendered(texture: converted.texture, stats: converted.stats, target: target,
                        pixels: (converted.texture.width, converted.texture.height),
                        appliedEV: outcome.progress?.autoExposureEV,
                        scratch: convertedScratch)
    }

    /// What `filePixels` produced: the destination-space texture, its size, and
    /// the numbers §7 asks of it.
    ///
    /// The texture stays unread here. `exportPrint` materialises the full-size
    /// `CGImage` it writes, while the page downsamples the texture once and
    /// materialises only that display image.
    struct Rendered {
        let texture: MTLTexture
        let stats: OutputTransformStats
        let target: CGColorSpace
        let pixels: (w: Int, h: Int)
        let appliedEV: Double?
        /// Keeps a pooled output alive until the caller has materialised it.
        /// Nil on the non-pooled path.
        let scratch: TextureStore.Scratch?
    }

    private static func exportPrint(session: Session, to out: URL, format: ExportFormat,
                                    quality: Double, recipe: ExportRecipe,
                                    sessionID: String,
                                    sourceEXIF: [CFString: Any]?) async throws -> Result {
        let r = try await filePixels(session: session, recipe: recipe, sessionID: sessionID)
        guard let image = r.texture.makeCGImage(space: r.target) else { throw ExportError.noPixels }
        let preview = writesPreviewPage(recipe) ? preview(of: image) : nil
        try write(image, to: out, format: format, quality: quality, preview: preview,
                  sourceEXIF: sourceEXIF)
        return Result(urls: [out], note: nil, appliedEV: r.appliedEV, pixels: r.pixels)
    }

    // MARK: - the Digital Intermediate

    /// RFC-028: **the frame's DI**, whatever paper the canvas shows — the
    /// engine renders it from the session's own negative through a pipeline of
    /// its own (`spk_render_digital_intermediate`), so choosing this export
    /// never touches the print on screen.
    ///
    /// Written as Kodak Cineon log, 16-bit, **untagged**: Cineon is not a
    /// display space, and a profile invites every viewer to "correct" the
    /// codes. The camera's EXIF travels, with its `ColorSpace` marked
    /// Uncalibrated (0xFFFF) — left as `sRGB`, ImageIO names an sRGB profile
    /// for it. The file's second page is the DI *view* (the canvas's own
    /// transform), so the TIFF has a picture for whoever opens it; the two
    /// view `.cube` files are copied beside it once per folder.
    ///
    /// Geometry is already in the negative (`node_geometry` runs on the film
    /// side). Post-Dev is not, and must not be: the DI is where a grade starts.
    private static func exportDigitalIntermediate(session: Session, to out: URL) async throws -> Result {
        let di = try await session.client.renderDigitalIntermediate()
        guard let texture = di.texture,
              let cg = texture.makeCGImage(space: CGColorSpaceCreateDeviceRGB())
            else { throw ExportError.noPixels }
        let preview = session.renderer.applyCineonView(to: texture)
            .flatMap { $0.makeCGImage() }
            .flatMap { self.preview(of: $0) }
        var exif = session.decoded?.sourceEXIF
        exif?[kCGImagePropertyExifColorSpace] = 0xFFFF
        try write(cg, to: out, format: .tiff, preview: preview, sourceEXIF: exif)
        let luts = (try? CineonLUT.copyBeside(directory: out.deletingLastPathComponent())) ?? []
        let note = L("Digital Intermediate: Cineon log in ProPhoto primaries, 16-bit and untagged. The two DI-view LUTs beside it (to ProPhoto RGB, to Rec.709) show it as the canvas does.",
                     zh: "数字中间片：ProPhoto 原色的 Cineon 对数，16 位，不嵌入色彩配置。旁边的两个数字中间片视图 LUT（转 ProPhoto RGB、转 Rec.709）按画布的方式显示它。")
        return Result(urls: [out] + luts, note: note, appliedEV: di.progress?.autoExposureEV,
                      pixels: (di.width, di.height))
    }

    /// Write one image.
    ///
    /// **`write` does not convert colour.** RFC-018 §5.4: it draws only when
    /// the *bit depth* has to change, and even then it redraws into the
    /// image's own colour space, so the numbers that reach the file are the
    /// ones the output transform produced. Callers hand it a `CGImage` already
    /// in the destination's space — `applyOutputTransform` then
    /// `makeCGImage(space:)` — and the tag travels with the pixels rather than
    /// being applied to them.
    ///
    /// The parameter that used to say otherwise is gone rather than ignored. A
    /// `colorSpace` argument that silently meant "and also re-draw into this"
    /// was the very Core Graphics clip this RFC removes; one that silently
    /// meant nothing would be worse, because it would look like it worked.
    ///
    /// Bit depth is decided by the format, not by the caller: ImageIO would
    /// otherwise write a 16-bit PNG.
    /// `preview` is written as a **second page** — IFD1 — and is the only
    /// multi-page case there is: the DI package's density channels are not a
    /// picture, so the file carries a picture for whoever opens it. It goes
    /// through the same depth reduction as the main image (a preview is not
    /// worth 16 bits) and keeps its own profile, which is what lets IFD0 stay
    /// untagged.
    @discardableResult
    static func write(_ image: CGImage, to url: URL, format: ExportFormat,
                      quality: Double = 0.95, preview: CGImage? = nil,
                      sourceEXIF: [CFString: Any]? = nil) throws -> URL {
        var cg = image
        let needsEight = format.isEightBit
        if needsEight {
            // Into the image's *own* space, so this is a depth reduction and
            // not a conversion. The fallback is for a CGImage that arrived
            // with no profile at all, which is the DI route.
            guard let converted = redraw(cg, in: cg.colorSpace ?? CGColorSpaceCreateDeviceRGB(),
                                         bitsPerComponent: 8) else { throw ExportError.noPixels }
            cg = converted
        }
        var small: CGImage?
        if let preview {
            small = redraw(preview, in: preview.colorSpace ?? CGColorSpaceCreateDeviceRGB(),
                           bitsPerComponent: 8)
        }
        // Written beside the destination under a hidden name and moved into
        // place once finalised, so a crash or a full disk mid-write never
        // leaves a truncated file under the real name — which a `.skip`
        // recipe would then keep forever as "already exists".
        let partial = url.deletingLastPathComponent()
            .appending(path: ".\(url.lastPathComponent).partial-\(UUID().uuidString.prefix(8))")
        defer { try? FileManager.default.removeItem(at: partial) }
        guard let dest = CGImageDestinationCreateWithURL(
            partial as CFURL, format.utType.identifier as CFString, small == nil ? 1 : 2, nil) else {
            throw ExportError.write(url)
        }
        var props: [CFString: Any] = [:]
        if format == .jpeg { props[kCGImageDestinationLossyCompressionQuality] = quality.clamped(to: 0.1...1) }
        if format == .tiff { props[kCGImagePropertyTIFFDictionary] = [kCGImagePropertyTIFFCompression: 5] }
        // EXIF is a side channel, never an engine input. Pass the source
        // dictionary through unchanged; ImageIO owns only the outer file
        // container and the export's pixels.
        if let sourceEXIF { props[kCGImagePropertyExifDictionary] = sourceEXIF }
        CGImageDestinationAddImage(dest, cg, props as CFDictionary)
        if let small { CGImageDestinationAddImage(dest, small, nil) }
        guard CGImageDestinationFinalize(dest) else { throw ExportError.write(url) }
        do {
            if FileManager.default.fileExists(atPath: url.path) {
                _ = try FileManager.default.replaceItemAt(url, withItemAt: partial)
            } else {
                try FileManager.default.moveItem(at: partial, to: url)
            }
        } catch {
            throw ExportError.write(url)
        }
        return url
    }

    /// Core Graphics does the colour conversion; this only sets up the
    /// context it does it in. 16-bit needs the little-endian byte order flag
    /// — without it the context is created but the channels come out
    /// byte-swapped, which looks like a colour-management bug and is not one.
    ///
    /// `size` is the context's, so a caller can ask for a *resample* rather
    /// than a copy — the preview page is the only one that does.
    private static func redraw(_ cg: CGImage, in space: CGColorSpace, bitsPerComponent: Int,
                               size: CGSize? = nil) -> CGImage? {
        let w = Int(size?.width ?? CGFloat(cg.width))
        let h = Int(size?.height ?? CGFloat(cg.height))
        guard w > 0, h > 0 else { return nil }
        var info = CGImageAlphaInfo.noneSkipLast.rawValue
        if bitsPerComponent == 16 { info |= CGBitmapInfo.byteOrder16Little.rawValue }
        guard let ctx = CGContext(data: nil, width: w, height: h,
                                  bitsPerComponent: bitsPerComponent, bytesPerRow: 0,
                                  space: space, bitmapInfo: info) else { return nil }
        ctx.interpolationQuality = .high
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        return ctx.makeImage()
    }

    /// The long edge of a preview page. **Chosen, not measured** — the one
    /// number here that is.
    ///
    /// It sits between the app's interactive tier (1600, what a screenful
    /// costs) and the file's own size, and it is what the export page shows
    /// once the file exists, so it has to survive being looked at rather than
    /// being a thumbnail. 2048 is a 5K pane's width at 1× and a laptop pane's
    /// at 2×; at 8 bits it makes a 6000 × 4000 TIFF's preview about a tenth
    /// of the file, which is the figure the user was given when they chose
    /// this as a per-recipe option. Move it if the page wants a different
    /// picture on screen — nothing else depends on it.
    static let previewLongEdge = 2048

    /// Whether this recipe's file carries a preview page: the rule the writer
    /// follows and the job log records, in one place so they cannot disagree.
    ///
    /// Two routes answer it differently, and each for its own reason. An
    /// ordinary TIFF's is the recipe's — **off by default**, so no existing
    /// recipe's bytes move. The Digital Intermediate's is unconditional,
    /// whatever the flag says: its pixels are Cineon codes, so the preview is
    /// the only rendered picture in it (`exportDigitalIntermediate`).
    static func writesPreviewPage(_ recipe: ExportRecipe) -> Bool {
        recipe.format == .di || (recipe.embedsPreview && recipe.format.carriesPreviewPage)
    }

    /// A **faithful small copy** of the file's own pixels: resampled, in the
    /// file's own space, 8-bit.
    ///
    /// Not a second render of the frame, which is the distinction that makes
    /// this worth having. The page shows the render before an export and the
    /// file's embedded preview after one; a preview produced by re-rendering
    /// would be a version of the *frame*, free to differ from the file in
    /// exactly the ways the page exists to show. This is the file, smaller.
    ///
    /// **A page, whenever one was asked for** — including for an export
    /// smaller than `longEdge`, where the page is the file's own size. The
    /// tempting alternative is to return nil there and save a copy of a small
    /// image, and it costs more than it saves: the reader's rule would become
    /// "the flag is on *and* the file is big enough", and a page that quietly
    /// falls back to the render is indistinguishable from one that never
    /// asked. `nil` is reserved for an image with no pixels at all.
    static func preview(of image: CGImage, longEdge: Int = previewLongEdge) -> CGImage? {
        let w = CGFloat(image.width), h = CGFloat(image.height)
        guard w > 0, h > 0 else { return nil }
        let scale = min(1, CGFloat(longEdge) / max(w, h))
        let size = CGSize(width: (w * scale).rounded(), height: (h * scale).rounded())
        return redraw(image, in: image.colorSpace ?? CGColorSpaceCreateDeviceRGB(),
                      bitsPerComponent: 8, size: size)
    }

    enum ExportError: Error, LocalizedError {
        case nothingOpen, noPixels, incompletePair, write(URL), directory(URL, String), colourSpace(String)
        var errorDescription: String? {
            switch self {
            case .nothingOpen: "Nothing is open."
            case .noPixels: "The render came back empty."
            case .incompletePair: "Fill both holes of the half-frame pair before exporting it."
            case .colourSpace(let why): "Could not convert to the recipe's colour space: \(why)."
            case .write(let u): "Could not write \(u.lastPathComponent)."
            case .directory(let u, let why):
                "Could not create \(u.path): \(why). Choose another folder in the export recipe."
            }
        }
    }
}
