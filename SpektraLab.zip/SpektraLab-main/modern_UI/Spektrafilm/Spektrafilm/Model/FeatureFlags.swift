//  FeatureFlags.swift — the switches that decide what the interface offers.
//
//  There is exactly one rule for what belongs here: a feature whose *code* is
//  worth keeping but whose *design* is not settled. Deleting such a feature
//  loses the work; shipping it teaches the user a shape that is about to
//  change. A flag keeps both the code and the honesty.
//
//  Each flag says who owns the decision and what has to happen before it
//  flips. A flag with no such note is a flag nobody will ever dare remove.

import Foundation

enum FeatureFlags {

    /// The 蒙版 (mask) system: local adjustments with a region.
    ///
    /// **Off, deliberately, and not because the code is broken.** The model
    /// (`Model/Mask.swift`), the kernel (`maskCoverage` in `Shaders.metal`),
    /// the sublayer (`Panels/Sections/MasksSection.swift`), the canvas
    /// controls (`Canvas/MaskOverlay.swift`) and the tests (`MaskTests`) all
    /// work and all stay. What is not settled is the *interaction design* —
    /// the user is writing the PRD, the interaction data and the layout — and
    /// the version built from the Lightroom reference is not the one they
    /// want.
    ///
    /// What the flag actually gates, and why each one matters:
    ///
    /// - `Session.syncMasks` stops packing masks for the kernel. This is the
    ///   important one: it means a sidecar that *already* has masks in it
    ///   renders as though it did not. The masks are still read, still
    ///   written, and still round-trip (`Sidecar` is untouched), so nothing
    ///   is lost — but no saved mask silently affects a picture while the
    ///   feature is not on offer.
    /// - `RightPanel` drops the sublayer, `EditorWindow` drops the overlay,
    ///   `SpektrafilmApp` drops the Mask menu, and `Session.maskHandles`
    ///   returns nothing, so the canvas cannot be dragged by grips that are
    ///   not drawn.
    ///
    /// Flip it back on when the user's own mask PRD lands and the sublayer is
    /// rebuilt to it.
    static let masks = false

    /// RFC-024's **Tone Mask** (the virtual contrast mask on the Pre-Dev rail).
    ///
    /// Off for the next version by the user's decision of 2026-09-29: "there
    /// is still some issue behind that". The engine node, the section
    /// (`ToneMaskSection`), the model and the tests all stay. Off, the section
    /// is not listed, the wire carries `contrast_mask_active = false` whatever
    /// a sidecar holds (so no saved mask silently shapes a print), and the
    /// clipboard's 遮罩 box is not offered while local masks are off too. The
    /// settings round-trip untouched. `nonisolated` because the wire reads it.
    nonisolated static let toneMask = false

    /// The **Enlarger** section on the darkroom rail: Print Exposure and the
    /// Yellow / Magenta filter axes.
    ///
    /// Off, and unlike `masks` this is a composition decision rather than a
    /// half-built feature. The 2026-09-17 drawing gives the left rail four
    /// sections; the enlarger was a fifth, kept because it is the only route
    /// to `print_exposure`. The cost was structural — a sixth hairline in a
    /// rail meant to read as four regions, which is most of what "the current
    /// version looks like a spreadsheet" was measuring — and the controls it
    /// exposes are the ones the reconstruction handoff §9 still lists as
    /// unclosed: raw CMY filter values in historical darkroom terms, which
    /// the product is supposed to stop asking users to understand.
    ///
    /// Flip it back on to reach those axes until §4's Render card lands and
    /// gives print exposure a home that is about the print rather than about
    /// the machine.
    static let enlarger = false

    /// **Black and white**: the product's own film profiles (Tri-X 400,
    /// T-Max 100, Neopan 100 Acros II, HP5 Plus 400) and the Multigrade IV RC
    /// paper they print on.
    ///
    /// On in every build since 1.3.3, by the owner's decision of 2026-10-09
    /// (it was Debug only earlier the same day: "wire it into a new debug
    /// version first"). The profiles are in every bundle
    /// (`engine/build.sh bundle`); off, the catalogue does not list them, so
    /// no picker, menu or agent tool offers one. What is wired: the film and
    /// its paper as a pair, grain as one layer, filter 2 on the enlarger, the
    /// film's own edge. What is not, and is why this is still a flag: the
    /// lens filter and the paper grade have no control yet (the engine has
    /// both -- `camera_filter`, API-SPEC §15, and `paper_grades.json`). Each
    /// film's grain is its own (`FilmParams.ownGrain`).
    ///
    /// Remove the flag when the filter and grade controls are designed.
    /// `nonisolated` because the catalogue reads it.
    nonisolated static let blackAndWhite = true

    /// The step 1 decode pipeline: when on, the single-flight pipeline owns
    /// the load path (decode, preview, and native-original stages).
    ///
    /// Flip it off if the pipeline has a bad interaction with the export
    /// harness. Remove the flag after the 30-click test has survived a week
    /// of real use. IMPL §9 says this can be turned off by a user without a
    /// build; this repository's FeatureFlags are compile-time `static let`s
    /// (as `masks` demonstrates), so changing it does require a build. That
    /// is a deliberate deviation from the document, called out rather than
    /// hidden.
    static let framePipeline = true

    /// The RFC-019 scratch texture pool.
    ///
    /// Off by default for one release. The pool reuses full-size export
    /// destinations and is the one memory change with a pixel-correctness
    /// surface: reuse is valid only when every kernel writes every texel and
    /// never reads its destination. Debug builds can turn it on with
    /// `SPEKTRAFILM_SCRATCH_POOL=1`; release builds never do.
    static let scratchPool: Bool = {
#if DEBUG
        ProcessInfo.processInfo.environment["SPEKTRAFILM_SCRATCH_POOL"] == "1"
#else
        false
#endif
    }()
}
