//  PrintProfileSection.swift — the paper list, grouped Still / Cine /
//  Positive, and the two actions that belong to the print.
//
//  The list is `StockList`, the same view the film list is, because the
//  drawing draws them the same: one well, one-line rows, a **band** on the
//  chosen one and the accent `CINE` pill on a cinema stock.
//
//  The Positive group holds one row, "No Print Profile": scan the developed
//  film instead of printing it. It is where a slide film belongs — printing
//  Provia onto Endura is a thing the engine will happily do and a thing
//  nobody wants — and it is also the only way to look at what the film stage
//  actually produced, orange mask and all.
//
//  Above it, the Digital group holds RFC-028's Digital Intermediate (数字中间片):
//  the negative with its orange mask removed and reversed on its own neutral
//  curve, as Cineon-style log. Like the Positive row it is a switch beside the
//  paper (`FilmParams.digitalIntermediate`), not a paper id.
//
//  It is `scan_film`, not a paper. Selecting it therefore does not clear the
//  paper: turn it off again and the print comes back on whatever was chosen
//  before, which is what makes it usable as a comparison rather than a
//  destination.
//
//  ## The two capsules, and why `Process` left them (v3, handoff §8.1)
//
//  v3 draws **Developed** and **Original** where `Process` and `Original`
//  were, and the handoff is explicit about the trap in that: "Do not rename
//  the solve button to Developed and leave its solve action behind that
//  label." A button reading *Developed* that auto-exposes the frame and
//  re-solves the filter pack is the worst available outcome — the word names
//  a state and the click performs an edit, so the one control in the section
//  that changes the picture is the one that looks like it changes the view.
//
//  So the pair is now **one two-state view selector**: Developed leaves the
//  original view, Original enters it, both through `showingOriginal`, which
//  is the state Space has always toggled on the canvas. Neither renders
//  anything.
//
//  **Solve did not disappear** — it is `Process this frame` in this section's
//  "•••", where it already was, with its own words and its own enabling. The
//  handoff's §8.1 recommendation is what this implements, and the decision it
//  asked the implementation session to make is the one recorded here.

import SwiftUI

struct PrintProfileSection: View {
    /// Rows of the print list on screen before it scrolls, at the section's
    /// own height: v4 shows eight papers.
    static let wellRows = 8

    @Bindable var session: Session

    /// The sentinel `StockList` row id for "No Print Profile". It is not a
    /// paper, so it cannot be a `print_stock` value — see `FilmParams.scanFilm`
    /// for why that separation is load-bearing — and this is the id the list
    /// uses to spell it without either side inventing a stock name.
    private static let positiveID = "__scan_film__"
    /// The Digital Intermediate's row, for the same reason.
    private static let digitalID = "__digital_intermediate__"

    /// Whether the chosen film is a slide film, in which case no paper on the
    /// list may be chosen.
    ///
    /// The section's own header has said since it was written that "printing
    /// Provia onto Endura is a thing the engine will happily do and a thing
    /// nobody wants". It was a comment; this is the rule. A positive is
    /// already a viewable image — the paper stage has nothing to interpret —
    /// so every paper greys out and "No Print Profile" is the only row left.
    private var filmIsPositive: Bool { session.filmIsPositive }

    private static var positiveOnlyReason: String { L(.reasonPositiveFilmDisablesPaper) }
    private static var silverPaperReason: String {
        L("A black-and-white paper. Choose a black-and-white film to print on it.",
          zh: "黑白相纸。选择黑白胶片后可使用。")
    }
    private static var colourPaperReason: String {
        L("A colour paper. A black-and-white film prints on a black-and-white paper.",
          zh: "彩色相纸。黑白胶片需使用黑白相纸印相。")
    }

    private var rows: [StockList.Row] {
        var out: [StockList.Row] = []
        for group in session.catalog.paperGroups where !group.papers.isEmpty {
            // Id keeps the catalogue's English title; only the label is
            // translated. Paper names themselves are profile names and stay.
            out.append(StockList.Row(id: "__group_" + group.title,
                                     name: L(paperGroup: group.title), isHeader: true))
            out += group.papers.map {
                // Silver film on silver paper, colour on colour: the rule is
                // `Session.selectPrintStock`'s, greyed here so it says why.
                let prints = session.catalog.canPrint(film: session.params.filmStock, on: $0.id)
                return StockList.Row(id: $0.id, name: $0.name, isCine: $0.isCine,
                              help: filmIsPositive ? "" : helpFor($0.id),
                              enabled: !filmIsPositive && prints,
                              disabledReason: filmIsPositive ? Self.positiveOnlyReason
                                  : prints ? "" : ($0.isMonochrome ? Self.silverPaperReason : Self.colourPaperReason))
            }
        }
        // A third "Positive" header, and a different string from the film
        // list's Positive: this one heads the paper list when the film is a
        // slide. The spec lists Positive as a *film* category (胶片分类) and
        // gives this one no row, so it is its own pair rather than collapsed
        // onto `filmGroupPositive` (it was left English until 1.2.2).
        out.append(StockList.Row(id: "__group_Digital", name: L(.printGroupDigital), isHeader: true))
        out.append(StockList.Row(id: Self.digitalID, name: L(.printDigitalIntermediate),
                                 help: filmIsPositive ? "" : L(.printDigitalIntermediateHelp),
                                 enabled: !filmIsPositive,
                                 disabledReason: filmIsPositive ? Self.positiveOnlyReason : ""))
        out.append(StockList.Row(id: "__group_Positive", name: L("Positive", zh: "正片"), isHeader: true))
        out.append(StockList.Row(id: Self.positiveID, name: L(.printNone),
                                 help: L("Scan the developed film instead of printing it — a slide film reads as a positive, a negative film as the negative it is.",
                                          zh: "不印相，直接扫描冲洗后的胶片：正片扫出正像，负片扫出负像。")))
        return out
    }

    var body: some View {
        PanelSection(L(.sectionPrint), key: "print", menu: { AnyView(menu) }) {
            VStack(alignment: .leading, spacing: 0) {
                StockList(rows: rows,
                          selected: session.params.scanFilm || filmIsPositive
                                    ? Self.positiveID
                                    : session.params.digitalIntermediate ? Self.digitalID
                                    : session.params.printStock,
                          visibleRows: Self.wellRows) { id in
                    if id == Self.positiveID {
                        var p = session.params; p.scanFilm = true; p.digitalIntermediate = false
                        session.params = p
                    } else if id == Self.digitalID {
                        session.selectDigitalIntermediate()
                    } else {
                        // `rowEnabled` already withholds the click; this is the
                        // second door, because the row's own gesture is not the
                        // only way an id reaches here.
                        guard !filmIsPositive else { return }
                        session.selectPrintStock(id)
                    }
                }
                // **Scope, on the row.** EDR is a *print* parameter: it
                // changes the paper's shoulder and toe in the engine, which
                // means the canvas, the export proof and the written file all
                // change together and none of them can disagree.
                //
                // That is why it is here, under the paper it belongs to, and
                // not on the export page. But sitting under a stock list it
                // read as a fourth kind of thing — the user's note was that
                // "its current position under Print leaves that scope
                // unclear" — because the controls near it are a viewing
                // choice (Original), a solve (Process) and a selection, and a
                // checkbox among those could be any of the three. The
                // sublabel settles it without moving it.
                RailRows {
                    // v4's **Print Effects**: everything the print stage adds
                    // on top of the paper's colour — glare, pre-flash, the
                    // Tone Mask — off in one place, and back exactly as it
                    // was (`FilmParams.printEffects` gates the wire and forgets
                    // nothing).
                    ToggleRow(label: L(.printEffects), isOn: param(\.printEffects),
                              labelFont: Theme.Font.edrLabel,
                              enabled: !session.params.scanFilm && !session.digitalIntermediateActive,
                              reason: session.digitalIntermediateActive
                                  ? L(.reasonDisabledInDigitalIntermediate) : L(.reasonEDRDisabledInScanFilm),
                              help: L("Glare and pre-flash. Off leaves the paper's colour transformation "
                                      + "and nothing else; their settings are kept.",
                                      zh: "耀光与预曝光。关闭后只保留相纸的色彩转换，它们的设置会被保留。"))
                    ToggleRow(label: L(.printEDR),
                              isOn: param(\.extendedDynamicRange),
                              labelFont: Theme.Font.edrLabel,
                              enabled: !session.params.scanFilm && !session.digitalIntermediateActive,
                              reason: session.digitalIntermediateActive
                                  ? L(.reasonDisabledInDigitalIntermediate) : L(.reasonEDRDisabledInScanFilm),
                              sublabel: L(.statusEDRScope),
                              help: L("A calibrated per-paper profile with more room in the "
                                      + "highlight shoulder and the toe. It is part of the print "
                                      + "stage, not a way of looking at it: what you see on the "
                                      + "canvas is what the exported file carries.",
                                      zh: "按相纸逐一校准的配置，在高光肩部与暗部趾部留出更多余量。它属于印相环节，"
                                      + "而不是一种查看方式：画布上看到的就是导出文件的内容。"))
                }
                .padding(.top, Theme.Metric.rowSpacing + 5)
            }
        }
    }

    private func param(_ keyPath: WritableKeyPath<FilmParams, Bool>) -> Binding<Bool> {
        Binding(get: { session.params[keyPath: keyPath] },
                set: { var p = session.params; p[keyPath: keyPath] = $0; session.params = p })
    }

    /// Only says something when there is something to say: which film the
    /// paper's baked LUT was paired with, and only while the fast flip is on.
    private func helpFor(_ stock: String) -> String {
        guard session.fastStockPreview, let entry = session.printLUTStocks[stock] else { return "" }
        return "Fast flip available — baked against \(entry.pairedFilm)."
    }

    private var menu: some View {
        Group {
            Button(L(.helpUseFilmPaper)) {
                if let t = session.catalog.stock(session.params.filmStock)?.targetPrint {
                    var p = session.params; p.printStock = t; p.scanFilm = false
                    p.digitalIntermediate = false; session.params = p
                }
            }
            // A positive declares none, so this would do nothing; saying so is
            // better than a live-looking item that silently does not fire.
            .disabled(filmIsPositive
                      || session.catalog.stock(session.params.filmStock)?.targetPrint == nil)
            // Also the Solve capsule above; kept here under its longer name.
            Button(L(.actionProcess)) { session.solveNow() }
                .disabled(!session.canSolve)
            Divider()
            // The caveat is in the label because it is the whole decision.
            // A toggle called "Fast preview" with the explanation somewhere
            // else is a toggle whose behaviour is a surprise.
            Toggle(L(.helpFastFlip),
                   isOn: Binding(get: { session.fastStockPreview },
                                 set: { session.fastStockPreview = $0 }))
                .disabled(session.printLUTStocks.isEmpty)
        }
    }
}
