//  EngineClient.swift — the render engine, in this process.
//
//  Replaces `ServiceClient`: no subprocess, no JSON-RPC framing, no workspace
//  directory, no `<repo>/.venv/bin/python`. The engine is C++ compiled into
//  this binary (RFC-014), reached through the `extern "C"` surface in
//  `spk_engine.h`, and it renders into an `MTLTexture` this app's own
//  `MTLDevice` can draw.
//
//  **The method surface is deliberately unchanged.** `call(_:_:as:)` takes the
//  same `Method` and the same `Encodable` request types and returns the same
//  `Decodable` response types as the stdio client did, because the engine
//  still speaks the same parameter schema and reports the same two version
//  numbers (contract §2). Requests are encoded to JSON, handed across as a
//  `const char*`, and the reply is decoded from the JSON that comes back. That
//  is not vestigial: parameters are small, the schema already exists, and a
//  struct-per-parameter boundary would break every time a slider is added
//  (RFC-014 §2.1).
//
//  What *did* change, and had to:
//
//  - **Renders return a texture, not a path.** `render(_:_:)` returns a
//    `RenderOutcome` carrying the `MTLTexture` the engine rendered into. The
//    old path wrote a raw rgba16 file and the client read it back — 10 ms of a
//    30.6 ms reprint, and a 364 MB file at the full tier. That file is gone.
//  - **`open` takes pixels, not a path.** `open(_:paramsDelta:)` hands the
//    engine an `EngineFrame` — the decode rendered into a shared `MTLBuffer`
//    — and the engine borrows it for the call (`spk_open_device`). There used
//    to be a file here: the importer wrote a 364 MB linear TIFF and this class
//    read it back, 6.4–7.1 s of a 45 MP open against a 47 ms render
//    (HANDOFF-OPEN-PATH). `call(.open, …)` is refused by name, like the
//    render methods, because what it needs does not fit through JSON.
//
//  Still an `actor`, but for a different reason than before. The stdio client
//  had to be serial because the wire was one request at a time and numba's
//  workqueue layer was not threadsafe. Neither is true now — the engine
//  reports `concurrent: true` and locks per session — so this serialises only
//  to keep one engine handle's lifecycle simple, and could be relaxed with
//  measurement behind it.

import Foundation
import Metal

/// One render's result: the reply the frontend already knows how to read, plus
/// the texture it used to have to load from a file.
///
/// `@unchecked Sendable` because `MTLTexture` is not `Sendable` and a texture
/// is exactly what this exists to carry. The same compromise `FullRenderEntry`
/// makes, for the same reason.
struct RenderOutcome: @unchecked Sendable {
    let response: RenderResponse
    let texture: MTLTexture?
    /// The numbers the render left in `session->progress`: the applied EV, and
    /// the per-node times when the engine was asked for them. Read *with* the
    /// render rather than fetched afterwards, so nothing else can render in
    /// between and hand back somebody else's exposure (RFC-016 §1.4).
    var progress: ProgressResponse?
}

/// `preview_stock_lut`'s result: the same kind of texture a render returns,
/// plus the metadata that says which table produced it.
struct StockLUTOutcome: @unchecked Sendable {
    let meta: StockLUTResponse
    let texture: MTLTexture?
    let width: Int
    let height: Int
}

/// `spk_render_digital_intermediate`'s picture: the frame's DI as Cineon codes.
struct DIOutcome: @unchecked Sendable {
    let meta: DigitalIntermediateResponse
    let texture: MTLTexture?
    let width: Int
    let height: Int
    var progress: ProgressResponse?
}

/// `spk_output_transform`'s reply (RFC-018 §5.2), decoded.
///
/// Not a wire type and deliberately not in `Methods.swift`: nothing here
/// crosses a process boundary any more, and this shape is the C ABI's rather
/// than the transport's.
struct OutputTransformReply: Decodable, Sendable {
    let sourceColorSpace: String
    let targetColorSpace: String
    /// As `shaders/nodes.metal` numbers the curves. Read from the engine
    /// rather than derived here: the mapping is the engine's, and a second
    /// copy of it is a second chance to decode with one curve and encode with
    /// another.
    let sourceCctfMode: Int
    let targetCctfMode: Int
    /// Source linear RGB → target linear RGB, row-major.
    let matrix: [Double]
    let gamutCompress: GamutCompress

    struct GamutCompress: Decodable, Sendable {
        let algorithm: String
        let mToXYZ: [Double]
        let mToRGB: [Double]
        /// The 22 CAM16 scalars `spk_cam16ucs_compress` reads out of `k`.
        let consts: [Double]
        let cmaxRows: Int
        let cmaxCols: Int
        let lightnessCompressionActive: Bool

        enum CodingKeys: String, CodingKey {
            case algorithm
            case mToXYZ = "m_to_xyz"
            case mToRGB = "m_to_rgb"
            case consts = "k"
            case cmaxRows = "cmax_rows"
            case cmaxCols = "cmax_cols"
            case lightnessCompressionActive = "lightness_compression_active"
        }
    }

    enum CodingKeys: String, CodingKey {
        case sourceColorSpace = "source_color_space"
        case targetColorSpace = "target_color_space"
        case sourceCctfMode = "source_cctf_mode"
        case targetCctfMode = "target_cctf_mode"
        case matrix
        case gamutCompress = "gamut_compress"
    }
}

/// One `spk_output_transform` fetch: the reply, and the C_max table it lent us.
///
/// The table is **copied out**, for the same reason `printLUTTable` copies:
/// the engine's pointer is good for the engine's lifetime, and wrapping it
/// would still be a dangling read the first time someone tears the engine down
/// with a transform installed. 184 kB once per destination is not worth that.
struct OutputTransformFetch: @unchecked Sendable {
    let reply: OutputTransformReply
    let cmax: [Float]
}

actor EngineClient {
    enum State: Sendable, Equatable { case stopped, starting, running, failed(String) }

    private(set) var state: State = .stopped
    /// The engine and its session are C objects, and ARC frees neither:
    /// releasing an `OpaquePointer` releases nothing. They live in a box of
    /// their own so that *dropping* the client frees them. A class `deinit` is
    /// not actor-isolated, and both alternatives are closed: Swift 6 refuses
    /// `deinit` access to the actor's own non-Sendable stored properties, and
    /// `isolated deinit` is macOS 15.4 against this app's 15.0.
    ///
    /// Until this existed only `stop()` freed them, and nothing calls it on
    /// the way out. A dropped client kept its engine, its baked constants, its
    /// print-LUT buffers, its setup cache and its open session's tier images
    /// for the life of the process: ~458 MB per client on a 5.6 MP frame, and
    /// this suite peaked 2.55 GB against 1.76 GB once they were freed. Every
    /// `Session` makes a client (there are 23 in the test suite), and the app
    /// makes one per `Session` too.
    ///
    /// The session goes first: `spk_session_release` hands it back to the
    /// engine that made it, and `~spk_engine` frees the GPU behind both — that
    /// order is deliberate on the C++ side too.
    private final class Handles: @unchecked Sendable {
        var engine: OpaquePointer?
        var session: OpaquePointer?
        deinit {
            if let session { spk_session_release(session) }
            if let engine { spk_engine_destroy(engine) }
        }
    }

    /// Touched only under this actor's isolation, and by `Handles.deinit` once
    /// the last reference to the client is gone.
    private let handles = Handles()
    private var engine: OpaquePointer? {
        get { handles.engine }
        set { handles.engine = newValue }
    }
    private var session: OpaquePointer? {
        get { handles.session }
        set { handles.session = newValue }
    }
    private var sessionID: String?
    private let device: MTLDevice
    /// Where this client's records go (RFC-016 §3 `engine`). The app's log by
    /// default; a `Session` that was handed a `Diagnostics` passes that one's,
    /// so a test reads the log it configured rather than a global.
    private let log: Log
    let resources: URL

    /// The `capabilities` block exactly as the engine wrote it, kept for the
    /// diagnostic bundle (RFC-016 §7 asks for "the startup capabilities JSON"):
    /// re-encoding the decoded `Capabilities` would be this app's idea of the
    /// block, not the engine's, and the whole point of the block is to be the
    /// engine's own statement of what it is.
    private(set) var capabilitiesJSON: String?

    /// Kept for source compatibility with the callers that used to need it.
    /// Nothing spawns a process any more, so nothing can terminate.
    var onTermination: (@Sendable (String) -> Void)?

    init(device: MTLDevice, resources: URL? = nil, log: Log = .shared) {
        self.device = device
        self.resources = resources ?? EngineClient.defaultResources()
        self.log = log
    }

    /// Where the baked constants, the film profiles and the Metal library are.
    ///
    /// In the shipped app they are in the bundle, which is the whole point:
    /// the app carries its own engine and its own data and does not walk up to
    /// a checkout. `SPEKTRAFILM_ENGINE_RESOURCES` and the repo fallback exist
    /// for a build run out of the tree, where `engine/build.sh bundle` may not
    /// have been run yet — and the fallback is *named* so a frame that renders
    /// from the repo instead of the bundle is visible rather than surprising.
    /// The bundle that carries Resources/: the app, or the test bundle.
    ///
    /// `Bundle.main` is wrong here and wrong in a way that only shows up under
    /// test: the unit-test target is standalone (no TEST_HOST), so
    /// `Bundle.main` is Xcode's test agent and every lookup misses. Same
    /// resolution `StockCatalog` uses, for the same reason.
    static var bundle: Bundle { Bundle(for: BundleToken.self) }
    private final class BundleToken {}

    static func defaultResources() -> URL {
        if let env = ProcessInfo.processInfo.environment["SPEKTRAFILM_ENGINE_RESOURCES"],
           !env.isEmpty {
            return URL(fileURLWithPath: env)
        }
        if let bundled = bundle.url(forResource: "spektrafilm_constants", withExtension: "bin",
                                    subdirectory: "Resources/engine") {
            return bundled.deletingLastPathComponent()
        }
        var url = bundle.bundleURL
        for _ in 0..<8 {
            url.deleteLastPathComponent()
            let candidate = url.appending(path: "engine/resources")
            if FileManager.default.fileExists(atPath: candidate.appending(path: "spektrafilm_constants.bin").path) {
                return candidate
            }
        }
        return bundle.bundleURL.appending(path: "Contents/Resources/Resources/engine")
    }

    /// True when the engine is reading its resources from the app bundle
    /// rather than from a checkout. Surfaced in `capabilities` so the status
    /// bar can say which — the lesson of a whole session spent measuring an
    /// engine nobody was running.
    var resourcesAreBundled: Bool {
        resources.path.hasPrefix(EngineClient.bundle.bundleURL.path)
    }

    func start() throws {
        guard state != .running, state != .starting else { return }
        state = .starting
        let constants = resources.appending(path: "spektrafilm_constants.bin")
        guard FileManager.default.fileExists(atPath: constants.path) else {
            let why = "the engine's resources are missing at \(resources.path); "
                    + "run engine/build.sh bundle"
            state = .failed(why)
            throw ClientError.noResources(resources.path)
        }
        // The app's own device goes in, so the engine renders into textures
        // this app can draw and nothing is copied across a process boundary.
        guard let handle = resources.path.withCString({ path in
            spk_engine_create(path, Unmanaged.passUnretained(device).toOpaque())
        }) else {
            let why = String(cString: spk_last_error(nil))
            state = .failed(why)
            throw ClientError.engine(why)
        }
        engine = handle
        state = .running
    }



    func stop() {
        releaseSession()
        if let engine { spk_engine_destroy(engine) }
        engine = nil
        state = .stopped
    }

    private func releaseSession() {
        if let session { spk_session_release(session) }
        session = nil
        sessionID = nil
    }

    enum ClientError: Error, CustomStringConvertible {
        case noResources(String), notRunning, engine(String), rpc(ServiceError)
        case badResponse(String), needsRenderPath(Method), needsFrame
        var description: String {
            switch self {
            case .noResources(let p): "the engine's resources are missing at \(p)"
            case .notRunning: "the render engine is not running"
            case .engine(let m): m
            case .rpc(let e): e.description
            case .badResponse(let s): "bad response: \(s)"
            case .needsRenderPath(let m):
                "\(m.rawValue) returns a texture; call EngineClient.render(_:_:) instead"
            case .needsFrame:
                "open takes pixels; call EngineClient.open(_:paramsDelta:) with an EngineFrame"
            }
        }
    }

    private func lastError() -> String {
        guard let engine else { return "the render engine is not running" }
        return String(cString: spk_last_error(engine))
    }

    /// Take ownership of a `char*` the engine allocated and decode it.
    private func decode<R: Decodable>(_ buffer: UnsafeMutablePointer<CChar>?, as: R.Type) throws -> R {
        guard let buffer else { throw ClientError.badResponse("no reply") }
        defer { spk_string_free(buffer) }
        let data = Data(bytes: buffer, count: strlen(buffer))
        do { return try JSONDecoder().decode(R.self, from: data) }
        catch { throw ClientError.badResponse(String(decoding: data.prefix(400), as: UTF8.self)) }
    }

    private func encode<P: Encodable>(_ params: P) throws -> String {
        String(decoding: try JSONEncoder().encode(params), as: UTF8.self)
    }

    // MARK: - the method surface

    func call<P: Encodable, R: Decodable>(_ method: Method, _ params: P,
                                          as: R.Type = R.self) async throws -> R {
        if state != .running { try start() }
        guard let engine else { throw ClientError.notRunning }
        let handle = engine

        switch method {
        case .capabilities:
            let json = String(cString: spk_capabilities(handle))
            capabilitiesJSON = json
            return try decodeOwned(json, as: R.self)
        case .paramsSchema:
            return try decodeOwned(String(cString: spk_params_schema(handle)), as: R.self)

        case .warmUp:
            let req = params as? WarmUpRequest
            var out: UnsafeMutablePointer<CChar>?
            let status = spk_warm_up(handle, req?.filmStock, req?.printStock, &out)
            guard status == SPK_OK else { throw ClientError.engine(lastError()) }
            return try decode(out, as: R.self)

        case .open:
            throw ClientError.needsFrame

        case .getParams:
            var out: UnsafeMutablePointer<CChar>?
            guard let session, spk_get_params(session, &out) == SPK_OK else {
                throw ClientError.engine(lastError())
            }
            return try decode(out, as: R.self)

        case .setParams:
            guard let session else { throw ClientError.notRunning }
            var out: UnsafeMutablePointer<CChar>?
            let delta = (params as? SetParamsRequest)?.paramsDelta ?? [:]
            let json = try encode(delta)
            let started = Date()
            guard json.withCString({ spk_set_params(session, $0, &out) }) == SPK_OK else {
                throw ClientError.engine(lastError())
            }
            noteSetParams(delta, elapsed: Date().timeIntervalSince(started) * 1000)
            return try decode(out, as: R.self)

        case .solve:
            guard let session else { throw ClientError.notRunning }
            let target = (params as? SolveRequest)?.target ?? "both"
            var out: UnsafeMutablePointer<CChar>?
            guard target.withCString({ spk_solve(session, $0, &out) }) == SPK_OK else {
                throw ClientError.engine(lastError())
            }
            return try decode(out, as: R.self)

        case .progress:
            guard let session else { throw ClientError.notRunning }
            var out: UnsafeMutablePointer<CChar>?
            guard spk_progress(session, nil, &out) == SPK_OK else {
                throw ClientError.engine(lastError())
            }
            return try decode(out, as: R.self)

        case .cancel:
            if let session { spk_cancel(session, nil) }
            return try decodeOwned("{}", as: R.self)

        case .reprint, .previewRender, .export, .digitalIntermediate, .previewStockLUT:
            // Every one of these produces an `MTLTexture`, and a texture
            // cannot travel through a `Decodable`. Rather than invent a JSON
            // shape that omits the only thing the caller wanted, they are
            // reached through `render(_:_:)`, `previewStockLUT(_:tier:)` and
            // `renderDigitalIntermediate()`, and this path refuses by name.
            //
            // The last three used to be refused as *unimplemented*
            // (ARCHITECTURE §8.8). They are implemented now; what is left is
            // that the reply does not fit through this door.
            throw ClientError.needsRenderPath(method)
        }
    }

    func call<R: Decodable>(_ method: Method, as: R.Type = R.self) async throws -> R {
        try await call(method, [String: String](), as: R.self)
    }

    /// A render, with the texture the engine drew into.
    ///
    /// `.export` is `.reprint` at the full tier and is spelled separately
    /// because the caller means something different by it: the reference's
    /// `RenderEngine.export` reuses the working-resolution negative when one
    /// is warm and renders the film side when it is not, which is exactly
    /// `spk_reprint`'s own contract.
    func render(_ method: Method, _ request: RenderRequest) async throws -> RenderOutcome {
        if state != .running { try start() }
        return try renderTexture(method, request)
    }

    // MARK: - the baked print LUTs

    /// Which print stocks have a shipped preview LUT, and what each was baked
    /// against. Empty when none are bundled — which is a fact about the
    /// build, so callers hide the feature rather than failing at it.
    func printLUTCatalog() throws -> [String: PrintLUTEntry] {
        if state != .running { try start() }
        guard let engine else { throw ClientError.notRunning }
        let json = String(cString: spk_print_lut_catalog(engine))
        return (try? JSONDecoder().decode([String: PrintLUTEntry].self, from: Data(json.utf8))) ?? [:]
    }

    /// One stock's table, copied out of the engine.
    ///
    /// The pointer the engine hands over is valid for the engine's lifetime,
    /// so wrapping it would work and would also be a dangling read the first
    /// time someone tears the engine down while a `.cube` is being written.
    /// 431 kB copied once per export is not worth that.
    func printLUTTable(_ printStock: String) throws -> (size: Int, table: [Float]) {
        if state != .running { try start() }
        guard let engine else { throw ClientError.notRunning }
        var pointer: UnsafePointer<Float>?
        var size: UInt32 = 0
        guard printStock.withCString({ spk_print_lut_table(engine, $0, &pointer, &size) }) == SPK_OK,
              let pointer, size > 1 else { throw ClientError.engine(lastError()) }
        let count = Int(size) * Int(size) * Int(size) * 3
        return (Int(size), Array(UnsafeBufferPointer(start: pointer, count: count)))
    }

    // MARK: - the output transform

    /// Everything the app's own output transform needs to go from `src` to
    /// `dst` (RFC-018 §5.2). A fetch, not a render: no pixels are touched here
    /// and none are returned.
    ///
    /// An unknown space **throws** rather than falling back — the engine's own
    /// rule, and the one thing this method must not paper over: a picture
    /// quietly converted to a space nobody asked for is worse than a failure
    /// that names the space.
    ///
    /// The gamut-compression settings are the engine's default because no wire
    /// field can change them; a session has exactly one
    /// (`GamutCompressSpec::output_default`), which is what passing NULL asks
    /// for. `gamutCompress` overrides it for a caller that wants a different
    /// kernel — the shape is `spk_output_transform`'s. `ColourManagement`
    /// passes its own export setting; `nil` remains for callers that need the
    /// engine default itself, including the measurement that separates the
    /// lightness compression from the gamut check.
    func outputTransform(src: String, dst: String,
                         gamutCompress: String? = nil) throws -> OutputTransformFetch {
        if state != .running { try start() }
        guard let engine else { throw ClientError.notRunning }
        var json: UnsafeMutablePointer<CChar>?
        var pointer: UnsafePointer<Float>?
        var count: UInt32 = 0
        // "" rather than NULL for "no override": the engine treats an empty
        // spec the same way, and this avoids an `Optional.withCString` that
        // does not exist.
        let spec = gamutCompress ?? ""
        let status = src.withCString { source in
            dst.withCString { target in
                spec.withCString { text in
                    spk_output_transform(engine, source, target, text, &json, &pointer, &count)
                }
            }
        }
        guard status == SPK_OK else { throw ClientError.engine(lastError()) }
        let reply: OutputTransformReply = try decode(json, as: OutputTransformReply.self)
        guard let pointer, count > 0 else { throw ClientError.badResponse("no C_max table") }
        return OutputTransformFetch(
            reply: reply,
            cmax: Array(UnsafeBufferPointer(start: pointer, count: Int(count))))
    }

    /// Flip to another print stock by table lookup rather than by re-running
    /// the print+scan chain.
    ///
    /// Measured on this engine at 45 MP, warm, against a reprint of the same
    /// tier: **2.0 ms against 9 ms** at live, 9.5 against 34 at preview,
    /// 47 against 167 at full. About 4x, because the cached negative goes
    /// through one trilinear sample instead of the print chain's dozen nodes
    /// — not the 190x in HANDOFF-PRINT-LUT §3.1, which was this kernel
    /// against *scipy on the CPU* and is the wrong comparison for a user who
    /// would otherwise have got a real reprint.
    ///
    /// What it leaves out is `scanning.glare` — spatial and stochastic, and
    /// not representable in a pointwise table — and the *user's* print grade:
    /// the table bakes the chain at the bake's own settings, so print
    /// exposure and the filter pack do not reach it. Both are why this is a
    /// look preview and `.export` still runs the real pipeline.
    func previewStockLUT(_ printStock: String, tier: String = "live") async throws -> StockLUTOutcome {
        if state != .running { try start() }
        guard let session else { throw ClientError.notRunning }
        var result = spk_result()
        var reply: UnsafeMutablePointer<CChar>?
        let status = printStock.withCString { stock in
            tier.withCString { t in spk_preview_stock_lut(session, stock, t, &result, &reply) }
        }
        guard status == SPK_OK else { throw ClientError.engine(lastError()) }
        let texture = result.texture.map { Unmanaged<MTLTexture>.fromOpaque($0).takeRetainedValue() }
        let meta: StockLUTResponse = try decode(reply, as: StockLUTResponse.self)
        return StockLUTOutcome(meta: meta, texture: texture,
                               width: Int(result.width), height: Int(result.height))
    }

    /// RFC-028: the frame's Digital Intermediate, full tier, whatever paper
    /// the session shows — Kodak Cineon log in the working primaries. The
    /// session's own pipeline and cached prints are not touched.
    func renderDigitalIntermediate() async throws -> DIOutcome {
        if state != .running { try start() }
        guard let session else { throw ClientError.notRunning }
        var result = spk_result()
        var reply: UnsafeMutablePointer<CChar>?
        guard spk_render_digital_intermediate(session, &result, &reply) == SPK_OK else {
            throw ClientError.engine(lastError())
        }
        let texture = result.texture.map { Unmanaged<MTLTexture>.fromOpaque($0).takeRetainedValue() }
        let meta: DigitalIntermediateResponse = try decode(reply, as: DigitalIntermediateResponse.self)
        return DIOutcome(meta: meta, texture: texture,
                         width: Int(result.width), height: Int(result.height),
                         progress: progressLocked())
    }

    // MARK: - RFC-023 / RFC-024 measurements

    /// RFC-023's Fit (API-SPEC §12): the medium, the scene, a suggestion and
    /// the solve for `request`'s pull-backs. Writes no parameter -- commit a
    /// valid fit's `paramsDelta` through `setParams` (or
    /// `SceneLatitudeSettings.apply`) like any other edit.
    func sceneLatitude(_ request: SceneLatitudeRequest) async throws -> SceneLatitudeResponse {
        if state != .running { try start() }
        guard let session else { throw ClientError.notRunning }
        let json = try encode(request)
        var out: UnsafeMutablePointer<CChar>?
        guard json.withCString({ spk_scene_latitude(session, $0, &out) }) == SPK_OK else {
            throw ClientError.engine(lastError())
        }
        return try decode(out, as: SceneLatitudeResponse.self)
    }

    /// Prints of the session's negative at several print settings, one after
    /// the other with nothing in between: each layer's delta is set, the tier
    /// reprinted, and `restore` put back at the end, so the session is left
    /// exactly as it was found. One actor call, so no other render can see
    /// the settings in between. A half-frame pair prints each frame this way.
    func renderLayers(sessionID: String, tier: String, layers: [[String: ParamValue]],
                      restore: [String: ParamValue]) throws -> [RenderOutcome] {
        if state != .running { try start() }
        var out: [RenderOutcome] = []
        defer {
            if !restore.isEmpty, let session, let json = try? encode(restore) {
                var reply: UnsafeMutablePointer<CChar>?
                _ = json.withCString { spk_set_params(session, $0, &reply) }
                if let reply { spk_string_free(reply) }
            }
        }
        for delta in layers {
            let r = try renderTexture(.reprint, RenderRequest(sessionID: sessionID, paramsDelta: delta, tier: tier))
            out.append(r)
        }
        return out
    }

    /// Where the gates are on the film canvas the last render laid out
    /// (API-SPEC §13), as rectangles normalised to the canvas with y down;
    /// empty with no film edge or before a render.
    func overscanGates() async throws -> [CGRect] {
        guard state == .running, let session else { return [] }
        var out: UnsafeMutablePointer<CChar>?
        guard spk_overscan_geometry(session, &out) == SPK_OK else { throw ClientError.engine(lastError()) }
        struct Reply: Decodable { let valid: Bool; let gates: [[Double]]? }
        let reply = try decode(out, as: Reply.self)
        guard reply.valid else { return [] }
        return (reply.gates ?? []).compactMap { q in
            guard q.count == 8 else { return nil }
            let xs = stride(from: 0, to: 8, by: 2).map { q[$0] }, ys = stride(from: 1, to: 8, by: 2).map { q[$0] }
            return CGRect(x: xs.min()!, y: ys.min()!, width: xs.max()! - xs.min()!, height: ys.max()! - ys.min()!)
        }
    }

    /// RFC-024's mask as a picture, for the canvas overlay (API-SPEC §11).
    /// The tier must have been rendered: the field is analysed on its cached
    /// negative. Copied out, because the engine's buffer is only valid until
    /// the next call on the session.
    func contrastMaskField(tier: String = "live") async throws -> ContrastMaskField {
        if state != .running { try start() }
        guard let session else { throw ClientError.notRunning }
        var pointer: UnsafePointer<Float>?
        var width: UInt32 = 0, height: UInt32 = 0
        guard tier.withCString({ spk_contrast_mask_field(session, $0, &pointer, &width, &height) }) == SPK_OK
        else { throw ClientError.engine(lastError()) }
        guard let pointer, width > 0, height > 0 else {
            return ContrastMaskField(width: 0, height: 0, delta: [])
        }
        let count = Int(width) * Int(height)
        return ContrastMaskField(width: Int(width), height: Int(height),
                                 delta: Array(UnsafeBufferPointer(start: pointer, count: count)))
    }

    // MARK: - the two calls that are not just JSON

    private func decodeOwned<R: Decodable>(_ json: String, as: R.Type) throws -> R {
        let data = Data(json.utf8)
        do { return try JSONDecoder().decode(R.self, from: data) }
        catch { throw ClientError.badResponse(String(json.prefix(400))) }
    }

    /// Open one frame: the engine borrows `frame`'s buffer for this call, runs
    /// `spk_take_rgb` into its own source, and keeps nothing of the caller's —
    /// so the caller can (and should) drop `frame` as soon as this returns.
    ///
    /// One session at a time, matching the engine's own shape and the
    /// frontend's: `open` on a new frame replaces the old one.
    func open(_ frame: EngineFrame, paramsDelta: [String: ParamValue]?) throws -> OpenResponse {
        if state != .running { try start() }
        guard let engine else { throw ClientError.notRunning }
        releaseSession()

        var reply: UnsafeMutablePointer<CChar>?
        let delta = try encode(paramsDelta ?? [:])
        let started = Date()
        var image = spk_device_image(buffer: Unmanaged.passUnretained(frame.buffer).toOpaque(),
                                     width: UInt32(frame.width),
                                     height: UInt32(frame.height),
                                     channels: UInt32(frame.channels))
        let handle: OpaquePointer? = delta.withCString { deltaPtr in
            withUnsafePointer(to: &image) { spk_open_device(engine, $0, deltaPtr, &reply) }
        }
        // What the engine does with the buffer: one kernel to its own
        // three-channel source, and the pipeline for the stock pair. There is
        // no host copy left to time — that was 235 ms of 727 MB at 45 MP.
        let openMs = Date().timeIntervalSince(started) * 1000
        EngineClient.logOpen(String(format: "engine.open: %d×%d, %.0f MB borrowed, %.0f ms",
                                    frame.width, frame.height,
                                    Double(frame.buffer.length) / 1e6, openMs))
        log.info(.engine, "open", [
            .init("w", frame.width), .init("h", frame.height),
            .init("px", frame.width * frame.height),
            .init("mb", Double(frame.buffer.length) / 1e6),
            .init("ms", openMs),
        ])
        guard let handle else { throw ClientError.engine(lastError()) }
        session = handle
        let decoded: OpenResponse = try decode(reply, as: OpenResponse.self)
        sessionID = decoded.sessionID
        return decoded
    }

    private func renderTexture(_ method: Method, _ request: RenderRequest) throws -> RenderOutcome {
        guard let session else { throw ClientError.notRunning }
        // A `params_delta` on a render is applied first, which is what the
        // wire's `reprint(params_delta:)` meant.
        if let delta = request.paramsDelta, !delta.isEmpty {
            var out: UnsafeMutablePointer<CChar>?
            let json = try encode(delta)
            let started = Date()
            guard json.withCString({ spk_set_params(session, $0, &out) }) == SPK_OK else {
                throw ClientError.engine(lastError())
            }
            if let out { spk_string_free(out) }
            noteSetParams(delta, elapsed: Date().timeIntervalSince(started) * 1000)
        }

        var result = spk_result()
        // `preview_render` forces the film side to run; `reprint` reuses the
        // cached negative. That is the same distinction the two engine
        // entry points make.
        let status = request.tier.withCString { tier in
            method == .previewRender
                ? spk_render(session, tier, &result)
                : spk_reprint(session, tier, &result)
        }
        guard status == SPK_OK else { throw ClientError.engine(lastError()) }

        // `+1`, per spk_engine.h: the engine handed over its only reference and
        // ARC owns it from here. `takeUnretainedValue` would free the pixels
        // out from under the canvas the moment this scope ended.
        let texture = result.texture.map { Unmanaged<MTLTexture>.fromOpaque($0).takeRetainedValue() }
        let response = RenderResponse(
            progressID: withUnsafeBytes(of: result.progress_id) { raw in
                String(cString: raw.bindMemory(to: CChar.self).baseAddress!)
            },
            tier: request.tier,
            elapsedMs: result.elapsed_ms,
            reprint: result.reprint != 0,
            negativeWasCached: result.negative_was_cached != 0,
            previewPath: nil,
            exportPath: nil,
            // No file is written any more, and saying so with `nil` is better
            // than inventing a path nothing can open.
            rawPath: nil,
            width: Int(result.width),
            height: Int(result.height))
        // One record per render (§3), here because this is the only place every
        // render passes through — including the ones the scheduler goes on to
        // drop, which never reach a callback the app can see.
        let progress = progressLocked()
        noteRender(method, request, response, progress: progress)
        return RenderOutcome(response: response, texture: texture, progress: progress)
    }

    // MARK: - what a render leaves in the log

    /// §3 `render`: tier, pixels, `elapsed_ms`, reprint or render, the applied
    /// EV, and the per-node times when the user has asked for them (§5.2).
    private func noteRender(_ method: Method, _ request: RenderRequest,
                            _ response: RenderResponse, progress: ProgressResponse?) {
        let width = response.width ?? 0
        let height = response.height ?? 0
        var fields: [LogField] = [
            .init("tier", request.tier),
            .init("kind", method == .previewRender ? "render" : "reprint"),
            .init("ms", response.elapsedMs),
            .init("w", width), .init("h", height), .init("px", width * height),
            .init("reprint", response.reprint),
            .init("negative_cached", response.negativeWasCached),
        ]
        // The EV the meter applied to this render's negative: the number the
        // export will also use, so a canvas and an export can be reconciled
        // (RFC-015 P.1, RFC-016 §1.4).
        if let ev = progress?.autoExposureEV { fields.append(.init("ev", ev)) }
        if EngineClient.nodeTimingsRequested, let times = progress?.nodeTimes, !times.isEmpty {
            for (node, ms) in times.sorted(by: { $0.key < $1.key }) { fields.append(.init(node, ms)) }
        }
        log.info(.render, "render", fields)
    }

    /// `SPEKTRAFILM_NODE_TIMINGS`, as the engine sees it: read from the C
    /// environment rather than `ProcessInfo.environment`, which is a snapshot
    /// taken at launch and would not notice the Settings toggle (§6).
    private nonisolated static var nodeTimingsRequested: Bool {
        getenv("SPEKTRAFILM_NODE_TIMINGS") != nil
    }

    /// §3 `engine`: every `set_params` with its elapsed time.
    ///
    /// Info past 100 ms and debug below it, and the split is the point:
    /// `spk_set_params` rebuilds the pipeline for anything outside
    /// `LIVE_MUTABLE`, so 160–250 ms of C_max table and tc_lut is an answer to
    /// "why is this edit slow" (§1.3) — and a 2 ms slider tick is an answer to
    /// nothing. Parameter *names* and values only: they are small, and §5.4's
    /// "no pixels" is about image data, not about the recipe.
    private func noteSetParams(_ delta: [String: ParamValue], elapsed: Double) {
        guard !delta.isEmpty else { return }
        let names = delta.keys.sorted().joined(separator: ",")
        log.log(elapsed >= 100 ? .info : .debug, .engine, "set_params", [
            .init("ms", elapsed), .init("count", delta.count), .init("params", names),
        ])
    }

    /// `spk_progress` for the session as it stands. Read after a render, on the
    /// actor, so nothing is in flight; the call takes no lock of its own
    /// (deliberately — `spk_cancel` reads the same struct during a render).
    private func progressLocked() -> ProgressResponse? {
        guard let session else { return nil }
        var out: UnsafeMutablePointer<CChar>?
        guard spk_progress(session, nil, &out) == SPK_OK else { return nil }
        return try? decode(out, as: ProgressResponse.self)
    }

    // MARK: - the open-path log

    /// On the same switch the canvas and the session read
    /// (`SPEKTRAFILM_CANVAS_LOG=1`), so that one run prints one story.
    ///
    /// Kept after the file handoff it was written to expose had gone, for the
    /// reason it was written: `Session`'s clock once called 6.2 s of reading a
    /// TIFF back `service.open`, a name that sounded like the engine working,
    /// and it took two sessions to notice (HANDOFF-OPEN-PATH §7). A number
    /// that names its cause is the cheap defence against that happening again.
    ///
    /// Read here rather than borrowed from `Renderer.logDraws`, which is
    /// main-actor-isolated and out of reach from this actor.
    private nonisolated static let logsOpenPath =
        ProcessInfo.processInfo.environment["SPEKTRAFILM_CANVAS_LOG"] == "1"

    private nonisolated static func logOpen(_ message: String) {
        guard logsOpenPath else { return }
        FileHandle.standardError.write(Data("session: \(message)\n".utf8))
    }
}
