//  SpektrafilmApp.swift — @main. One window, one session, one service; or,
//  with `cli` or `mcp` as the first argument, the same session without a
//  window (RFC-026).
//
//  `--snapshot WxH out.png [--open path] [--wait s] [--folded left|right|both]`
//  renders the window at
//  that size and writes a PNG: the harness `Tools/snapshot.sh` uses it to
//  compare the built interface against the drawing at three window sizes.

import AppKit
import SwiftUI

/// Three front doors on one binary (RFC-026 §2). `cli …` and `mcp` never
/// create an `NSApplication`, so an agent's call opens no window and puts no
/// icon in the Dock; anything else is the app. This file is the one the test
/// target leaves out, which is why the switch lives here.
@main
enum SpektraLabEntry {
    static func main() {
        let args = Array(CommandLine.arguments.dropFirst())
        guard let door = args.first, door == "cli" || door == "mcp" else {
            SpektrafilmApp.main()
            return
        }
        AgentOutput.takeStdout()
        let argv = door == "cli" ? Array(args.dropFirst()) : ["mcp"]
        Task { @MainActor in
            let code = await AgentCLI.run(argv)
            exit(code)
        }
        // The main actor is the main queue; the run loop drains it and keeps
        // Core Image's and the engine's main-thread callbacks working.
        RunLoop.main.run()
    }
}

struct SpektrafilmApp: App {
    /// One session for the app's lifetime; the delegate reaches it here.
    @MainActor static let session = Session()
    private var session: Session { Self.session }
    @NSApplicationDelegateAdaptor private var delegate: AppDelegate
    private let snapshot = SnapshotRequest.parse(CommandLine.arguments)

    var body: some Scene {
        Window("SpektraLab", id: "editor") {
            EditorWindow(session: session)
                .id(InterfaceScaleStore.shared.scale)
                .environment(\.snapshotMode, snapshot != nil)
                // The capture is of its own window (`runSnapshot`), not this one.
                .environment(\.snapshotCapture, false)
                .frame(minWidth: Theme.Metric.minWindow.width, minHeight: Theme.Metric.minWindow.height)
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unifiedCompact)
        .defaultSize(width: 1920, height: 1080)
        .commands { EditorCommands(session: session) }

        // Not decoration: two of the three licences the bundle carries
        // require something visible, and CC BY-SA 4.0 names an About screen
        // by example as a place the attribution has to survive. See
        // `AboutWindow`.
        Window("About SpektraLab", id: "about") {
            AboutWindow()
        }
        .windowResizability(.contentSize)
        .defaultPosition(.center)

        // **Not a `Settings` scene.** It is the obvious way to get the app
        // menu's "Settings…" item for free, and in this app it stops SwiftUI
        // from ever creating the *editor* window. Bisected: with a `Settings`
        // scene the app has one window at the boot handover (the boot window)
        // and the `Window("SpektraLab", id: "editor")` scene's window is never
        // made; without it there are two, the second being SwiftUI's
        // `TUINSWindow`. The app launched to a boot screen that never went
        // away.
        //
        // So the page is an ordinary `Window` and the menu item is declared
        // by hand in `EditorCommands` via `CommandGroup(replacing: .appSettings)`,
        // which puts it in the same place with the same ⌘, shortcut.
        // `RFC-016 §6` is what the page itself is for.
        Window("Settings", id: "settings") {
            SettingsWindow(session: session)
                .id(InterfaceScaleStore.shared.scale)
        }
        .windowResizability(.contentSize)
        .defaultPosition(.center)

        // The export page, as a window rather than the sheet it used to be
        // (RFC-018 §6). Sizing is left free — the page is three cards and a
        // picture, and it has a minimum of its own — and the editor opens it
        // through `ExportWindowID.scene` when something asks for an export.
        Window("Export", id: ExportWindowID.scene) {
            ExportWindow(session: session)
                .id(InterfaceScaleStore.shared.scale)
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unifiedCompact)
        // The drawing's own window size, so what opens is what was drawn.
        .defaultSize(width: Theme.Metric.Export.width, height: Theme.Metric.Export.height)
        .defaultPosition(.center)
    }
}

struct EditorCommands: Commands {
    let session: Session
    /// `openWindow` reaches the "about" scene declared above. A `Commands`
    /// struct can read the environment; a plain `Button` action cannot open a
    /// scene any other way.
    @Environment(\.openWindow) private var openWindow

    private func openAbout() { openWindow(id: "about") }

    var body: some Commands {
        CommandGroup(replacing: .appInfo) {
            Button("About SpektraLab") { openAbout() }
        }
        // Hand-declared because the page is a `Window` and not a `Settings`
        // scene — see the comment on that scene. Same slot, same shortcut.
        CommandGroup(replacing: .appSettings) {
            Button("Settings…") { openWindow(id: "settings") }
                .keyboardShortcut(",", modifiers: .command)
        }
        CommandGroup(replacing: .newItem) {
            Button("Open…") { session.openPanel() }.keyboardShortcut("o")
            Button("Export…") { session.showExport = true }.keyboardShortcut("e").disabled(session.selection == nil)
        }
        CommandGroup(replacing: .undoRedo) {
            Button("Undo") { session.undo() }.keyboardShortcut("z").disabled(!session.canUndo)
        }
        CommandGroup(replacing: .pasteboard) {
            Button("Copy Settings") { session.copySettings() }
                // Capture One's adjustment clipboard uses ⇧⌘C / ⇧⌘V. Keep
                // plain ⌘C / ⌘V available for the system pasteboard.
                .keyboardShortcut("c", modifiers: [.command, .shift]).disabled(!session.canCopySettings)
            Button("Paste Settings") { session.pasteSettings() }
                .keyboardShortcut("v", modifiers: [.command, .shift]).disabled(!session.canPasteSettings)
            Divider()
            Button("Select All Photos") { session.selectAllFrames() }
                .keyboardShortcut("a", modifiers: .command).disabled(!session.canSelectAllFrames)
            Button("Sync Settings") { session.syncSettings() }
                .disabled(!session.canSyncSettings)
        }
        CommandMenu("View") {
            // Greyed out in the crop tool, where the view is fitted to the
            // whole turned photograph and the user cannot move it
            // (`Session.zoomLocked`). Disabled rather than silently ignored:
            // a shortcut that does nothing and says nothing reads as a bug.
            // These follow Capture One's Viewer shortcuts: ⌘+ / ⌘− step the
            // magnification, while comma and period are fit and 100%.
            Button("Zoom In") { session.zoomStep(1) }
                .keyboardShortcut("+", modifiers: .command).disabled(session.zoomLocked)
            Button("Zoom Out") { session.zoomStep(-1) }
                .keyboardShortcut("-", modifiers: .command).disabled(session.zoomLocked)
            Button("Zoom to Fit") { session.zoomToFit() }
                .keyboardShortcut(",", modifiers: []).disabled(session.zoomLocked)
            Button("Zoom to 100 %") { session.zoomTo(fraction: 1) }
                .keyboardShortcut(".", modifiers: []).disabled(session.zoomLocked)
            Divider()
            Button("Toggle Side Panels") {
                withAnimation(.easeOut(duration: 0.18)) {
                    let c = !(session.leftCollapsed && session.rightCollapsed)
                    session.leftCollapsed = c; session.rightCollapsed = c
                }
            }.keyboardShortcut("b", modifiers: .command)
            Button("Toggle Filmstrip") { withAnimation { session.filmstripCollapsed.toggle() } }.keyboardShortcut("f", modifiers: [.command, .shift])
            Divider()
            // The only door onto this now — the right rail's dotted-circle glyph
            // is gone, so this label is also the state read-out. It says which
            // way the switch is pointing, as Before / After does, because a
            // bypass you forgot you turned on looks like a broken render.
            Button(session.adjustments.enabled ? "Bypass Adjustments" : "Restore Adjustments") {
                var a = session.adjustments; a.enabled.toggle(); session.adjustments = a
            }.keyboardShortcut("b", modifiers: [.command, .shift])
            // Capture One uses Y for its single Before/After toggle. The
            // split-view mode is a separate affordance in Capture One, but
            // SpektraLab exposes one comparison state, so Y owns that toggle.
            Button(session.comparing ? "Hide Before / After" : "Before / After") { session.comparing.toggle() }
                .keyboardShortcut("y", modifiers: [])
                .disabled(!session.canCompare)
            Divider()
            Button("Restart Render Service") { session.restartService() }
                .keyboardShortcut("r", modifiers: [.command, .option])
                .disabled(session.selection == nil)
        }
        CommandMenu("Frame") {
            // Capture One uses the unmodified arrow keys for adjacent images.
            // The canvas responder already routes the same keys to
            // `stepFrame`, so this remains usable when the viewer has focus.
            Button("Previous") { session.selectRelative(-1) }
                .keyboardShortcut(.leftArrow, modifiers: [])
            Button("Next") { session.selectRelative(1) }
                .keyboardShortcut(.rightArrow, modifiers: [])
            Divider()
            // Two neighbouring half frames on one piece of film: the picked
            // frames fill its holes (design-proposals/half-frame-pair-2026-10-02).
            Button("New Half-Frame Pair") { session.newPair() }
                .keyboardShortcut("j", modifiers: .command).disabled(!session.canMakePair)
            Divider()
            // These three were the left rail header's "•••" until the
            // 2026-09-17 drawing took the menu off that row. They are frame
            // commands rather than panel commands — each one is about the
            // open frame's settings — so this is where they belong anyway.
            Button("Reset Film, Paper, Camera and Enlarger") { session.resetParams() }
            Button("Reset Adjustments") { session.resetAdjustments() }
            Button("Reveal Settings in Finder") {
                guard let u = session.selection else { return }
                // The settings live in the app's store, not beside the image,
                // so this can be asked for a frame that has never been saved.
                // Show the folder in that case rather than selecting nothing.
                let sidecar = Sidecar.url(for: u)
                if FileManager.default.fileExists(atPath: sidecar.path) {
                    NSWorkspace.shared.activateFileViewerSelecting([sidecar])
                } else {
                    NSWorkspace.shared.open(Sidecar.storeDirectory)
                }
            }
            .disabled(session.selection == nil)
        }
        // Withdrawn with the rest of the mask system (`FeatureFlags.masks`):
        // a menu is a promise, and this one cannot be kept while the feature
        // is not on offer.
        if FeatureFlags.masks {
            CommandMenu("Mask") {
                Button("Add Linear Gradient") { session.addMask(.linearGradient) }
                    .keyboardShortcut("m", modifiers: [.shift])
                Button("Add Radial Gradient") { session.addMask(.radialGradient) }
                    .keyboardShortcut("m", modifiers: [.shift, .option])
                Button("Add Luminance Range") { session.addMask(.luminanceRange) }
                Button("Add Colour Range") { session.addMask(.colorRange) }
                Divider()
                Button("Show Mask Overlay") { session.maskOverlayVisible.toggle() }
                    .keyboardShortcut("o", modifiers: [.shift])
                Button("Invert Mask") {
                    if var m = session.selectedMask { m.inverted.toggle(); session.selectedMask = m }
                }.disabled(session.selectedMask == nil)
                Divider()
                Button("Delete Mask") { if let id = session.selectedMaskID { session.deleteMask(id) } }
                    .disabled(session.selectedMaskID == nil)
            }
        }
        CommandMenu("Crop") {
            Button("Rotate Left") { session.geometry = session.geometry.turned(by: -1) }
                .keyboardShortcut("[", modifiers: [.command, .option])
            Button("Rotate Right") { session.geometry = session.geometry.turned(by: 1) }
                .keyboardShortcut("]", modifiers: [.command, .option])
            Button("Flip Horizontally") { var g = session.geometry; g.flipH.toggle(); session.geometry = g }
            Button("Flip Vertically") { var g = session.geometry; g.flipV.toggle(); session.geometry = g }
            Divider()
            Button("Reset Crop") { session.geometry = .default }
        }
        CommandMenu("Tool") {
            Button("Select") { session.tool = .select }.keyboardShortcut("v", modifiers: [])
            Button("Hand") { session.tool = .hand }.keyboardShortcut("h", modifiers: [])
            Button("Crop") { session.tool = .crop }.keyboardShortcut("c", modifiers: [])
        }
    }
}

struct SnapshotRequest {
    var size: CGSize
    var output: URL
    var open: URL?
    var wait: Double = 1.5
    /// Optional zoom fraction (1 = 100 %). Drives the detail-tier path so the
    /// resolution escalation can be captured without a person at the keyboard.
    var zoom: CGFloat?
    /// `--geometry x,y,w,h,angle[,turns]` — a crop to apply before capturing,
    /// so the geometry path has a regression capture like everything else.
    /// Unlike the canvas itself, this one *is* visible offscreen: the
    /// geometry is applied while sampling, and `renderOffscreen` samples.
    var geometry: Geometry?
    /// `--mask kind,exposure[,overlay]` — add one mask before capturing, so
    /// the mask path has a regression capture. Like the geometry, this one is
    /// visible offscreen: it happens in the `layer2` kernel and
    /// `renderOffscreen` runs it.
    var mask: (kind: MaskComponentKind, exposure: Double, overlay: Bool)?
    /// `--compare [position]` — put the before/after split up before
    /// capturing. Like the geometry and the mask, this one *is* visible
    /// offscreen: the split happens in `canvasFragment` and `renderOffscreen`
    /// draws through it. Only the shader half is captured — the line, the
    /// handle and the labels are SwiftUI over the canvas, and `SnapshotCanvas`
    /// stands in for the Metal view — which is exactly the half that a test
    /// cannot otherwise see.
    var compare: Double?
    /// `--original` — hold "show original" (Space, or the Original pill)
    /// before capturing. Visible offscreen because `renderOffscreen` swaps in
    /// the original exactly as `draw` does; it did not, until the display
    /// decode made the original worth looking at.
    var original = false
    /// `--export` — capture the export page instead of the editor. It is its
    /// own window now (RFC-018 §6), so it is its own root view here; the soft
    /// proof in the centre is a render of the real recipe, which is the thing
    /// this flag exists to be able to look at. `--export-grid` is the same
    /// capture with the centre in Grid mode, so both halves of the mode
    /// transition have one.
    var export = false
    var exportGrid = false
    /// `--settings general|rendering|memory|diagnostics|agents` — capture
    /// that page of Settings (RFC-026's paged window).
    var settings: SettingsPage?
    /// `--folded left|right|both` — capture with a rail folded.
    ///
    /// The 2026-09-17 PRD makes one requirement about state rather than
    /// layout: the two `sidebar` buttons "must also remain on the screen at
    /// any given time, but moves according to a good way". A folded rail has
    /// no header to hold its own button, so the bar takes it — and that is a
    /// thing that can only be *seen*, in the state the harness otherwise goes
    /// out of its way to reset (`session.leftCollapsed = false`, so that a
    /// panel folded days ago cannot silently remove a region from the
    /// measurement). This asks for the state on purpose.
    var foldLeft = false
    var foldRight = false
    /// `--film-edge` — capture with the film edge on. `--pair-layer film|left|right`
    /// — capture a half-frame pair with that layer picked.
    var filmEdge = false
    /// `--date-back` — capture with the date back on.
    var dateBack = false
    var pairLayer: PairLayer?
    /// `--pair-zoom f s` — in the pair's crop mode, zoom the picked frame by
    /// `f` about a point of its hole, and capture `s` seconds later: a short
    /// wait is the gesture's own picture, a long one the develop that follows.
    var pairZoom: (factor: Double, wait: Double)?

    static func parse(_ args: [String]) -> SnapshotRequest? {
        guard let i = args.firstIndex(of: "--snapshot"), args.count > i + 2 else { return nil }
        let dims = args[i + 1].split(separator: "x").compactMap { Double($0) }
        guard dims.count == 2 else { return nil }
        var r = SnapshotRequest(size: CGSize(width: dims[0], height: dims[1]), output: URL(fileURLWithPath: args[i + 2]))
        if let j = args.firstIndex(of: "--open"), args.count > j + 1 { r.open = URL(fileURLWithPath: args[j + 1]) }
        if let j = args.firstIndex(of: "--wait"), args.count > j + 1, let w = Double(args[j + 1]) { r.wait = w }
        if let j = args.firstIndex(of: "--folded"), args.count > j + 1 {
            let which = args[j + 1]
            r.foldLeft = which == "left" || which == "both"
            r.foldRight = which == "right" || which == "both"
        }
        if let j = args.firstIndex(of: "--zoom"), args.count > j + 1, let z = Double(args[j + 1]) { r.zoom = CGFloat(z) }
        if let j = args.firstIndex(of: "--mask"), args.count > j + 1 {
            let f = args[j + 1].split(separator: ",").map(String.init)
            if let kind = MaskComponentKind(rawValue: f[0]) {
                r.mask = (kind, f.count > 1 ? Double(f[1]) ?? -1 : -1, f.count > 2 && f[2] == "overlay")
            }
        }
        r.original = args.contains("--original")
        r.filmEdge = args.contains("--film-edge")
        r.dateBack = args.contains("--date-back")
        if let j = args.firstIndex(of: "--pair-layer"), args.count > j + 1 { r.pairLayer = PairLayer(rawValue: args[j + 1]) }
        if let j = args.firstIndex(of: "--pair-zoom"), args.count > j + 2,
           let f = Double(args[j + 1]), let w = Double(args[j + 2]) { r.pairZoom = (f, w) }
        r.exportGrid = args.contains("--export-grid")
        r.export = r.exportGrid || args.contains("--export")
        if let j = args.firstIndex(of: "--settings"), args.count > j + 1 {
            r.settings = SettingsPage(rawValue: args[j + 1])
        }
        if let j = args.firstIndex(of: "--compare") {
            r.compare = args.count > j + 1 ? (Double(args[j + 1]) ?? 0.5) : 0.5
        }
        if let j = args.firstIndex(of: "--geometry"), args.count > j + 1 {
            let f = args[j + 1].split(separator: ",").compactMap { Double($0) }
            if f.count >= 5 {
                var g = Geometry()
                g.crop = CropRect(x: f[0], y: f[1], width: f[2], height: f[3])
                g.angle = f[4]
                if f.count > 5 { g.quarterTurns = Int(f[5]) }
                r.geometry = g
            }
        }
        return r
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    var session: Session? { SpektrafilmApp.session }
    var snapshot: SnapshotRequest?
    private let boot = BootWindowController()
    /// Typing keys go to the field being typed into, not to the menu's
    /// single-key shortcuts (`TypingKeyGuard`).
    private var typingKeyGuard: Any?

    func applicationDidFinishLaunching(_ notification: Notification) {
        typingKeyGuard = TypingKeyGuard.install()
        // First statement, before anything else can want to log: `start()`
        // opens the session file, and records written before it (the static
        // session's own warm-up) land in the ring buffer only.
        Diagnostics.shared.start()
        NSApp.appearance = NSAppearance(named: .darkAqua)
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
        // Parsed here, not handed over from the scene: this fires before any
        // view's onAppear.
        guard let snapshot = SnapshotRequest.parse(CommandLine.arguments) else {
            openCommandLineArguments()
            // Not in snapshot mode: `Tools/snapshot.sh` builds its own window
            // and must not have a second one taking key, and a capture that
            // photographed a splash screen would be worthless.
            if let session { boot.present(session: session) }
            return
        }
        self.snapshot = snapshot
        Task { await runSnapshot(snapshot) }
    }

    func application(_ application: NSApplication, open urls: [URL]) {
        session?.open(urls: urls)
    }

    /// A path passed on the command line opens too, so a capture or a script
    /// can launch one instance with a frame already in it rather than
    /// launching and then sending an open event to a second copy.
    func openCommandLineArguments() {
        let paths = CommandLine.arguments.dropFirst().filter { !$0.hasPrefix("-") }
        let urls = paths.map { URL(fileURLWithPath: $0) }.filter { FileManager.default.fileExists(atPath: $0.path) }
        if !urls.isEmpty { session?.open(urls: urls) }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    func applicationWillTerminate(_ notification: Notification) {
        // The session-end record. Its absence on the next launch is the only
        // evidence a hang, a jetsam kill or a panic leaves (§1.7), so this
        // must come before anything here that could itself fail.
        Diagnostics.shared.finish()
        session?.flushSave()
        if let c = session?.client { Task { await c.stop() } }
    }

    private var snapshotWindow: NSWindow?

    /// Leave the log honest on the way out.
    ///
    /// `runSnapshot` ends in `exit()`, which does not run
    /// `applicationWillTerminate` — so without this every capture leaves a
    /// session file with no end record, and RFC-016 §1.7 then reports an
    /// unclean exit on the *next* launch. The harness runs constantly, so
    /// that is a permanent false alarm in the user's own log. A snapshot that
    /// finished is a clean exit and must say so.
    private func snapshotExit(_ code: Int32) -> Never {
        Diagnostics.shared.finish()
        exit(code)
    }

    /// A compare or Original capture must not photograph the preview standing
    /// in for the native decode. Bounded so a failed render cannot hold the
    /// snapshot harness open.
    private func waitForNativeOriginal(_ session: Session) async {
        let deadline = Date().addingTimeInterval(5)
        while session.nativeOriginalInFlight, Date() < deadline {
            try? await Task.sleep(for: .milliseconds(50))
        }
    }

    private func runSnapshot(_ req: SnapshotRequest) async {
        guard let session else { snapshotExit(2) }
        // Own window, own hosting view: the capture must not depend on when
        // (or whether) the SwiftUI scene's window is ordered in.
        if let page = req.settings {
            UserDefaults.standard.set(page.rawValue, forKey: Session.uiKey + "settingsPage")
        }
        let host = NSHostingView(rootView: req.settings != nil
            ? AnyView(SettingsWindow(session: session))
            : req.export
            ? AnyView(ExportWindow(session: session, startIn: req.exportGrid ? .grid : .viewer))
            : AnyView(EditorWindow(session: session).environment(\.snapshotMode, true)))
        // Borderless, and never `center()`. A titled window is constrained to
        // the screen's visible frame, so asking for 1920×1080 on a smaller
        // display silently produced a 1800-point-wide capture — and every
        // measurement taken against it was then wrong by that ratio. The
        // capture must not depend on which display happens to be attached.
        let window = NSWindow(contentRect: CGRect(origin: .zero, size: req.size),
                              styleMask: [.borderless], backing: .buffered, defer: false)
        window.appearance = NSAppearance(named: .darkAqua)
        window.contentView = host
        window.setFrame(CGRect(origin: .zero, size: req.size), display: true)
        host.frame = CGRect(origin: .zero, size: req.size)
        window.makeKeyAndOrderFront(nil)
        snapshotWindow = window
        // A capture must show the interface, not whatever panel the last
        // session happened to leave folded: the collapse flags persist in
        // UserDefaults, and a filmstrip collapsed days ago silently removed a
        // whole card from the measurement.
        session.leftCollapsed = req.foldLeft
        session.rightCollapsed = req.foldRight
        session.filmstripCollapsed = false
        // The same trap, one door along: a **rail width** persists too, and a
        // rail dragged to 328 in some earlier session makes every capture
        // measure 74 pt wide of the drawing. A capture is a check against the
        // drawing, so it has to be of a fresh install — which is exactly what
        // `PanelWidthRange.standard` is.
        session.snapshotPanelWidths = true
        // And one door further along again: a `PanelSection`'s expansion is
        // `@AppStorage` too, under `Session.uiKey + "section.<key>"`, and the
        // export page's collapse flag is its own key. Neither was reset, so
        // an export capture showed whichever sections a real run had last
        // left open — Summary is declared `initiallyExpanded: false` and
        // photographed expanded, which is precisely the kind of difference a
        // capture is supposed to be trusted about. Clearing the keys restores
        // every section's declared default rather than asserting a list of
        // them here, so a new section is covered the day it is written.
        let defaults = UserDefaults.standard
        for (k, _) in defaults.dictionaryRepresentation()
        where k.hasPrefix(Session.uiKey + "section.") {
            defaults.removeObject(forKey: k)
        }
        defaults.removeObject(forKey: Session.uiKey + "exportSettingsCollapsed")
        // `topCollapsed` is not reset here any more: the top bar is the
        // window's first row and cannot be collapsed, so no view reads that
        // flag. The stored property stays for one release so a preferences
        // file written by an older build still decodes.
        try? await Task.sleep(for: .milliseconds(300))
        if let open = req.open {
            session.open(urls: [open])
            // Opening a *folder* lands the app in Browse with nothing chosen,
            // which is right for a person and wrong for the one capture that
            // has to have a picture in it: the export page's centre pane is a
            // soft proof of the frame on the canvas.
            // A plain click, not `select`: the capture's export page reads its
            // batch off the picked set, and a frame put on the canvas without
            // being picked would export a folder of nothing.
            if req.export, session.selection == nil, let first = session.frames.first {
                session.click(first.id)
            }
            // A capture is of the *print*. The app itself opens onto the
            // decode and waits for a person to ask for the develop, and a
            // snapshot has nobody at the keyboard — so it asks here.
            if req.filmEdge {
                var p = session.params
                p.filmEdge.active = true
                session.params = p
            }
            if req.dateBack {
                var p = session.params
                p.dateBack.active = true
                session.params = p
            }
            if let layer = req.pairLayer { session.pairLayer = layer }
            session.requestPrint()
        }
        let deadline = Date().addingTimeInterval(req.wait)
        while Date() < deadline {
            try? await Task.sleep(for: .milliseconds(200))
            if req.open == nil { if Date() > deadline.addingTimeInterval(-req.wait + 1.0) { break } }
            // A live service session id, not the sidecar's `state`: a frame
            // edited in an earlier run is `.processed` on disk before this run
            // has rendered anything, and the loop used to exit on it.
            else if session.serviceSessionIDForExport != nil, !session.previewSoft,
                    let sel = session.selection, !session.busy,
                    session.frameStates[sel] == .processed { break }
        }
        try? await Task.sleep(for: .milliseconds(400))
        if let z = req.pairZoom, let side = session.pairLayer.side, let hole = session.pairHoleRects[side] {
            session.togglePairPlacing()
            // Off the hole's middle, so a zoom that drifts shows.
            let at = CGPoint(x: hole.minX + 0.3 * hole.width, y: hole.minY + 0.35 * hole.height)
            _ = session.placementZoomed(by: z.factor, at: at)
            try? await Task.sleep(for: .milliseconds(Int(z.wait * 1000)))
        }
        if let m = req.mask {
            session.addMask(m.kind)
            if var mask = session.selectedMask {
                mask.adjustments.exposure = m.exposure
                session.selectedMask = mask
            }
            session.maskOverlayVisible = m.overlay
            try? await Task.sleep(for: .milliseconds(300))
        }
        if let g = req.geometry {
            session.geometry = g.fitted(in: session.sourceImageSize)
            try? await Task.sleep(for: .milliseconds(300))
        }
        if let position = req.compare {
            session.comparePosition = position
            session.comparing = true
            await waitForNativeOriginal(session)
        }
        if req.original {
            session.toggledOriginal(true)
            await waitForNativeOriginal(session)
        }
        if let zoom = req.zoom {
            session.zoomTo(fraction: zoom)
            // A zoom no longer asks for a render, so this waits for the canvas
            // to be *settled* rather than for a tier: the native render of the
            // current grade, which the settle after the last edit started.
            let deadline = Date().addingTimeInterval(90)
            while Date() < deadline {
                try? await Task.sleep(for: .milliseconds(250))
                if !session.fullPending, session.canvasIsSettled { break }
            }
            try? await Task.sleep(for: .milliseconds(400))
        }
        host.frame = CGRect(origin: .zero, size: req.size)
        host.layoutSubtreeIfNeeded()
        let view: NSView = host
        guard view.bounds.size == req.size,
              let rep = view.bitmapImageRepForCachingDisplay(in: view.bounds) else {
            FileHandle.standardError.write(Data("snapshot: wanted \(req.size), view is \(view.bounds.size)\n".utf8))
            snapshotExit(3)
        }
        view.cacheDisplay(in: view.bounds, to: rep)
        guard let png = rep.representation(using: .png, properties: [:]) else { snapshotExit(4) }
        try? png.write(to: req.output)
        print("snapshot \(Int(req.size.width))x\(Int(req.size.height)) → \(req.output.path)")
        snapshotExit(0)
    }
}
